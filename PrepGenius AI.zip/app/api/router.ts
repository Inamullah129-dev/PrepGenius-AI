import { authRouter } from "./auth-router";
import { profileRouter } from "./profile-router";
import { interviewRouter } from "./interview-router";
import { resumeRouter } from "./resume-router";
import { analyticsRouter } from "./analytics-router";
import { careerRouter } from "./career-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  profile: profileRouter,
  interview: interviewRouter,
  resume: resumeRouter,
  analytics: analyticsRouter,
  career: careerRouter,
});

export type AppRouter = typeof appRouter;
