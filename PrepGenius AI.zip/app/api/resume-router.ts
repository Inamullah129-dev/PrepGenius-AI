import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { resumes, analytics } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const resumeRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.resumes.findMany({
      where: eq(resumes.userId, ctx.user.id),
      orderBy: desc(resumes.createdAt),
    });
  }),

  getById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.resumes.findFirst({
        where: eq(resumes.id, input.id),
      });
    }),

  create: authedQuery
    .input(
      z.object({
        fileUrl: z.string().optional(),
        fileName: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [result] = await db
        .insert(resumes)
        .values({
          userId: ctx.user.id,
          fileUrl: input.fileUrl,
          fileName: input.fileName,
        })
        .$returningId();
      return db.query.resumes.findFirst({
        where: eq(resumes.id, result.id),
      });
    }),

  analyze: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const resume = await db.query.resumes.findFirst({
        where: eq(resumes.id, input.id),
      });
      if (!resume) return null;

      // Simulated ATS analysis
      const atsScore = Math.floor(Math.random() * 30) + 65; // 65-95
      const allSkills = [
        "JavaScript",
        "TypeScript",
        "React",
        "Node.js",
        "Python",
        "SQL",
        "AWS",
        "Docker",
        "GraphQL",
        "MongoDB",
        "Redis",
        "Kubernetes",
      ];
      const foundSkills = allSkills.filter(() => Math.random() > 0.3);
      const missingSkills = allSkills.filter((s) => !foundSkills.includes(s));

      const analysis = {
        missingSkills: missingSkills.slice(0, 4),
        formattingIssues: [
          "Consider using a single-column layout for better ATS parsing",
          "Add more quantifiable achievements",
          "Use standard section headings",
        ],
        suggestions: [
          "Include more relevant keywords from the job description",
          "Add a skills section with technical competencies",
          "Quantify your achievements with metrics",
          "Use action verbs at the beginning of bullet points",
        ],
        keywordMatch: Math.floor(Math.random() * 25) + 70,
        roleMatch: "Senior Software Engineer",
      };

      const parsedData = {
        skills: foundSkills,
        experience: [
          "Software Engineer at Tech Corp (2021-Present)",
          "Junior Developer at Startup Inc (2019-2021)",
        ],
        education: ["BS Computer Science, University (2019)"],
        keywords: foundSkills.slice(0, 6),
      };

      await db
        .update(resumes)
        .set({
          atsScore,
          parsedData,
          analysis,
        })
        .where(eq(resumes.id, input.id));

      // Update analytics
      const existingAnalytics = await db.query.analytics.findFirst({
        where: eq(analytics.userId, ctx.user.id),
      });
      if (existingAnalytics) {
        await db
          .update(analytics)
          .set({ atsScore })
          .where(eq(analytics.userId, ctx.user.id));
      } else {
        await db.insert(analytics).values({
          userId: ctx.user.id,
          atsScore,
        });
      }

      return db.query.resumes.findFirst({
        where: eq(resumes.id, input.id),
      });
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(resumes).where(eq(resumes.id, input.id));
      return { success: true };
    }),
});
