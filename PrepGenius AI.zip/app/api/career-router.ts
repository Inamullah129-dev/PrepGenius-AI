import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { analytics } from "@db/schema";
import { eq } from "drizzle-orm";

const CAREER_ROADMAPS: Record<
  string,
  {
    milestones: Array<{
      title: string;
      description: string;
      duration: string;
      skills: string[];
    }>;
    certifications: string[];
    recommendations: string[];
  }
> = {
  "Frontend Engineer": {
    milestones: [
      {
        title: "HTML, CSS & JavaScript Mastery",
        description: "Build strong fundamentals in web technologies",
        duration: "1-2 months",
        skills: ["HTML5", "CSS3", "JavaScript ES6+"],
      },
      {
        title: "React Framework Proficiency",
        description: "Master component-based development",
        duration: "2-3 months",
        skills: ["React", "Hooks", "State Management"],
      },
      {
        title: "Advanced Frontend Patterns",
        description: "Learn performance optimization and testing",
        duration: "2-3 months",
        skills: ["TypeScript", "Testing", "Performance"],
      },
      {
        title: "Full-Stack Capabilities",
        description: "Expand to backend and deployment",
        duration: "3-4 months",
        skills: ["Node.js", "GraphQL", "CI/CD"],
      },
    ],
    certifications: [
      "AWS Certified Developer",
      "Meta Frontend Developer Certificate",
      "Google UX Design Certificate",
    ],
    recommendations: [
      "Build a portfolio with 3+ projects",
      "Contribute to open source",
      "Practice system design interviews",
      "Learn a backend language",
    ],
  },
  "Backend Engineer": {
    milestones: [
      {
        title: "Programming Fundamentals",
        description: "Master a backend language deeply",
        duration: "1-2 months",
        skills: ["Java/Python/Go", "OOP", "Data Structures"],
      },
      {
        title: "Database & API Design",
        description: "Learn data modeling and RESTful APIs",
        duration: "2-3 months",
        skills: ["SQL", "NoSQL", "API Design", "Caching"],
      },
      {
        title: "Distributed Systems",
        description: "Understand microservices and messaging",
        duration: "3-4 months",
        skills: ["Microservices", "Message Queues", "Docker"],
      },
      {
        title: "Cloud & DevOps",
        description: "Deploy and scale applications",
        duration: "2-3 months",
        skills: ["AWS/GCP", "Kubernetes", "CI/CD", "Monitoring"],
      },
    ],
    certifications: [
      "AWS Solutions Architect",
      "Certified Kubernetes Administrator",
      "Oracle Java Certification",
    ],
    recommendations: [
      "Build a REST API project",
      "Learn database optimization",
      "Practice system design",
      "Set up CI/CD pipelines",
    ],
  },
  "Full Stack Engineer": {
    milestones: [
      {
        title: "Frontend Fundamentals",
        description: "Master HTML, CSS, and JavaScript",
        duration: "1-2 months",
        skills: ["HTML5", "CSS3", "JavaScript", "React"],
      },
      {
        title: "Backend Development",
        description: "Learn server-side programming",
        duration: "2-3 months",
        skills: ["Node.js", "Express", "Databases", "Auth"],
      },
      {
        title: "Integration & Deployment",
        description: "Connect frontend to backend",
        duration: "2-3 months",
        skills: ["APIs", "State Management", "Deployment"],
      },
      {
        title: "Advanced Architecture",
        description: "Build scalable applications",
        duration: "3-4 months",
        skills: ["System Design", "Microservices", "Cloud"],
      },
    ],
    certifications: [
      "AWS Certified Developer",
      "MongoDB Certified Developer",
      "Docker Certified Associate",
    ],
    recommendations: [
      "Build end-to-end applications",
      "Learn both SQL and NoSQL",
      "Practice deployment workflows",
      "Understand security best practices",
    ],
  },
  "Data Scientist": {
    milestones: [
      {
        title: "Programming & Math Foundations",
        description: "Learn Python and statistics",
        duration: "1-2 months",
        skills: ["Python", "Statistics", "Linear Algebra"],
      },
      {
        title: "Data Analysis & Visualization",
        description: "Process and visualize data",
        duration: "2-3 months",
        skills: ["Pandas", "NumPy", "Matplotlib", "SQL"],
      },
      {
        title: "Machine Learning",
        description: "Build predictive models",
        duration: "3-4 months",
        skills: ["Scikit-learn", "TensorFlow", "Feature Engineering"],
      },
      {
        title: "Production ML Systems",
        description: "Deploy and monitor ML models",
        duration: "2-3 months",
        skills: ["MLOps", "Cloud ML", "Model Monitoring"],
      },
    ],
    certifications: [
      "Google Professional Data Engineer",
      "AWS Machine Learning Specialty",
      "Microsoft Azure Data Scientist",
    ],
    recommendations: [
      "Complete Kaggle competitions",
      "Build a portfolio of projects",
      "Learn big data tools",
      "Practice SQL extensively",
    ],
  },
};

export const careerRouter = createRouter({
  roadmap: authedQuery
    .input(z.object({ role: z.string().min(1) }))
    .query(async ({ input }) => {
      const roadmap =
        CAREER_ROADMAPS[input.role] || CAREER_ROADMAPS["Full Stack Engineer"];
      return roadmap;
    }),

  report: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userAnalytics = await db.query.analytics.findFirst({
      where: eq(analytics.userId, ctx.user.id),
    });

    const readinessScore = userAnalytics?.jobReadiness ?? 0;

    return {
      readinessScore,
      jobReadiness:
        readinessScore >= 80
          ? "High"
          : readinessScore >= 60
            ? "Moderate"
            : "Developing",
      skillGaps: [
        { skill: "System Design", priority: "high" as const },
        { skill: "Behavioral Interviews", priority: "medium" as const },
        { skill: "Algorithms", priority: "high" as const },
        { skill: "Resume Optimization", priority: "low" as const },
      ],
      recommendations: [
        "Focus on system design fundamentals for senior roles",
        "Practice behavioral questions using the STAR method",
        "Complete 5+ more mock interviews for confidence",
        "Optimize your resume for ATS with relevant keywords",
        "Study company-specific interview patterns",
      ],
      nextSteps: [
        "Schedule a system design mock interview",
        "Review data structures and algorithms",
        "Update LinkedIn profile with recent projects",
        "Research target companies' interview processes",
      ],
    };
  }),
});
