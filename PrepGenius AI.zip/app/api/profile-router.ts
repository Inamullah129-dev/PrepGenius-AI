import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { profiles } from "@db/schema";
import { eq } from "drizzle-orm";

export const profileRouter = createRouter({
  get: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const profile = await db.query.profiles.findFirst({
      where: eq(profiles.userId, ctx.user.id),
    });
    return profile ?? null;
  }),

  create: authedQuery
    .input(
      z.object({
        title: z.string().max(255).optional(),
        bio: z.string().optional(),
        location: z.string().max(255).optional(),
        linkedin: z.string().max(500).optional(),
        github: z.string().max(500).optional(),
        portfolio: z.string().max(500).optional(),
        education: z
          .array(
            z.object({
              school: z.string(),
              degree: z.string(),
              field: z.string(),
              startYear: z.string(),
              endYear: z.string(),
            }),
          )
          .optional(),
        experience: z
          .array(
            z.object({
              company: z.string(),
              role: z.string(),
              duration: z.string(),
              description: z.string(),
            }),
          )
          .optional(),
        skills: z.array(z.string()).optional(),
        projects: z
          .array(
            z.object({
              name: z.string(),
              description: z.string(),
              tech: z.array(z.string()),
              link: z.string().optional(),
            }),
          )
          .optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const completionScore = calculateCompletion(input);
      const [result] = await db
        .insert(profiles)
        .values({
          userId: ctx.user.id,
          ...input,
          completionScore,
        })
        .$returningId();
      return db.query.profiles.findFirst({
        where: eq(profiles.id, result.id),
      });
    }),

  update: authedQuery
    .input(
      z.object({
        title: z.string().max(255).optional(),
        bio: z.string().optional(),
        location: z.string().max(255).optional(),
        linkedin: z.string().max(500).optional(),
        github: z.string().max(500).optional(),
        portfolio: z.string().max(500).optional(),
        education: z
          .array(
            z.object({
              school: z.string(),
              degree: z.string(),
              field: z.string(),
              startYear: z.string(),
              endYear: z.string(),
            }),
          )
          .optional(),
        experience: z
          .array(
            z.object({
              company: z.string(),
              role: z.string(),
              duration: z.string(),
              description: z.string(),
            }),
          )
          .optional(),
        skills: z.array(z.string()).optional(),
        projects: z
          .array(
            z.object({
              name: z.string(),
              description: z.string(),
              tech: z.array(z.string()),
              link: z.string().optional(),
            }),
          )
          .optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.query.profiles.findFirst({
        where: eq(profiles.userId, ctx.user.id),
      });
      if (!existing) {
        const completionScore = calculateCompletion(input);
        const [result] = await db
          .insert(profiles)
          .values({
            userId: ctx.user.id,
            ...input,
            completionScore,
          })
          .$returningId();
        return db.query.profiles.findFirst({
          where: eq(profiles.id, result.id),
        });
      }
      const merged = {
        title: input.title ?? existing.title ?? undefined,
        bio: input.bio ?? existing.bio ?? undefined,
        location: input.location ?? existing.location ?? undefined,
        linkedin: input.linkedin ?? existing.linkedin ?? undefined,
        github: input.github ?? existing.github ?? undefined,
        portfolio: input.portfolio ?? existing.portfolio ?? undefined,
        education: input.education ?? existing.education ?? undefined,
        experience: input.experience ?? existing.experience ?? undefined,
        skills: input.skills ?? existing.skills ?? undefined,
        projects: input.projects ?? existing.projects ?? undefined,
      };
      const completionScore = calculateCompletion(merged);
      await db
        .update(profiles)
        .set({ ...input, completionScore })
        .where(eq(profiles.userId, ctx.user.id));
      return db.query.profiles.findFirst({
        where: eq(profiles.userId, ctx.user.id),
      });
    }),

  delete: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    await db.delete(profiles).where(eq(profiles.userId, ctx.user.id));
    return { success: true };
  }),
});

function calculateCompletion(
  input: Partial<{
    title: string | undefined;
    bio: string | undefined;
    location: string | undefined;
    linkedin: string | undefined;
    github: string | undefined;
    portfolio: string | undefined;
    education: Array<unknown> | undefined;
    experience: Array<unknown> | undefined;
    skills: Array<unknown> | undefined;
    projects: Array<unknown> | undefined;
  }>,
): number {
  let score = 0;
  const fields = [
    input.title,
    input.bio,
    input.location,
    input.linkedin,
    input.github,
    input.education,
    input.experience,
    input.skills,
    input.projects,
  ];
  fields.forEach((f) => {
    if (f && (Array.isArray(f) ? f.length > 0 : f.length > 0)) score += 11;
  });
  return Math.min(100, score + 1);
}
