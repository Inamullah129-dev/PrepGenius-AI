import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { analytics, interviews } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const analyticsRouter = createRouter({
  dashboard: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userAnalytics = await db.query.analytics.findFirst({
      where: eq(analytics.userId, ctx.user.id),
    });

    const userInterviews = await db.query.interviews.findMany({
      where: eq(interviews.userId, ctx.user.id),
      orderBy: desc(interviews.createdAt),
      limit: 5,
    });

    const allInterviews = await db.query.interviews.findMany({
      where: eq(interviews.userId, ctx.user.id),
      orderBy: desc(interviews.createdAt),
    });

    // Calculate skill areas
    const skillAreas = [
      { name: "Technical", score: 0, count: 0 },
      { name: "Communication", score: 0, count: 0 },
      { name: "Problem Solving", score: 0, count: 0 },
      { name: "Confidence", score: 0, count: 0 },
    ];

    for (const iv of allInterviews) {
      if (iv.technicalScore) {
        skillAreas[0].score += iv.technicalScore;
        skillAreas[0].count++;
      }
      if (iv.communicationScore) {
        skillAreas[1].score += iv.communicationScore;
        skillAreas[1].count++;
      }
      if (iv.problemSolvingScore) {
        skillAreas[2].score += iv.problemSolvingScore;
        skillAreas[2].count++;
      }
      if (iv.confidenceScore) {
        skillAreas[3].score += iv.confidenceScore;
        skillAreas[3].count++;
      }
    }

    const skillBreakdown = skillAreas.map((s) => ({
      name: s.name,
      score: s.count > 0 ? Math.round((s.score / s.count) * 10) : 0,
    }));

    // Monthly progress
    const monthlyProgress: Array<{ month: string; score: number }> = [];
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const monthStr = months[d.getMonth()];
      const monthInterviews = allInterviews.filter((iv) => {
        const ivDate = new Date(iv.createdAt);
        return (
          ivDate.getMonth() === d.getMonth() &&
          ivDate.getFullYear() === d.getFullYear() &&
          iv.status === "completed"
        );
      });
      const avgScore =
        monthInterviews.length > 0
          ? Math.round(
              monthInterviews.reduce((s, iv) => s + (iv.totalScore ?? 0), 0) /
                monthInterviews.length,
            )
          : 0;
      monthlyProgress.push({ month: monthStr, score: avgScore });
    }

    // Weekly activity
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const weeklyActivity = days.map((day) => ({
      day,
      count: Math.floor(Math.random() * 4),
    }));

    return {
      stats: {
        totalInterviews: userAnalytics?.totalInterviews ?? 0,
        averageScore: userAnalytics?.averageScore ?? 0,
        bestScore: userAnalytics?.bestScore ?? 0,
        atsScore: userAnalytics?.atsScore ?? 0,
        profileCompletion: userAnalytics?.profileCompletion ?? 0,
        jobReadiness: userAnalytics?.jobReadiness ?? 0,
      },
      recentInterviews: userInterviews,
      skillBreakdown,
      monthlyProgress,
      weeklyActivity,
      weakAreas: userAnalytics?.weakAreas ?? [],
      strongAreas: userAnalytics?.strongAreas ?? [],
    };
  }),

  progress: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userAnalytics = await db.query.analytics.findFirst({
      where: eq(analytics.userId, ctx.user.id),
    });

    return {
      skillGrowth: userAnalytics?.skillGrowth ?? [
        { skill: "React", score: 75, trend: "up" as const },
        { skill: "Node.js", score: 68, trend: "up" as const },
        { skill: "System Design", score: 55, trend: "stable" as const },
        { skill: "Algorithms", score: 62, trend: "down" as const },
        { skill: "Communication", score: 80, trend: "up" as const },
      ],
      weakAreas: userAnalytics?.weakAreas ?? [
        "System Design",
        "Behavioral Questions",
      ],
      strongAreas: userAnalytics?.strongAreas ?? [
        "Technical Communication",
        "React Fundamentals",
      ],
      learningProgress: [
        { topic: "Data Structures", completed: 85 },
        { topic: "Algorithms", completed: 62 },
        { topic: "System Design", completed: 45 },
        { topic: "Behavioral", completed: 78 },
        { topic: "Frontend", completed: 92 },
      ],
    };
  }),
});
