import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { interviews, questions, responses, analytics } from "@db/schema";
import { eq, desc, and } from "drizzle-orm";

const INTERVIEW_QUESTIONS: Record<
  string,
  Array<{ question: string; category: string; difficulty: string; expectedAnswer: string }>
> = {
  "Frontend Engineer": [
    {
      question: "Explain the virtual DOM and how React uses it to optimize rendering.",
      category: "React",
      difficulty: "medium",
      expectedAnswer: "The virtual DOM is a lightweight JavaScript representation of the actual DOM. React creates a new virtual DOM tree on state changes, diffs it against the previous tree, and only updates changed nodes in the real DOM.",
    },
    {
      question: "How do you approach state management in large React applications?",
      category: "React",
      difficulty: "medium",
      expectedAnswer: "Use Context API for global state, Zustand/Redux for complex state, keep state close to usage, and consider state colocation principles.",
    },
    {
      question: "Explain CSS specificity and how to manage styling in large applications.",
      category: "CSS",
      difficulty: "medium",
      expectedAnswer: "CSS specificity follows inline > ID > class/attribute > element. Use CSS modules, styled-components, or utility frameworks like Tailwind for maintainable styling.",
    },
    {
      question: "What are the key differences between var, let, and const in JavaScript?",
      category: "JavaScript",
      difficulty: "easy",
      expectedAnswer: "var is function-scoped and hoisted, let and const are block-scoped. const prevents reassignment but allows mutation of objects/arrays.",
    },
    {
      question: "Describe the event loop in JavaScript and how microtasks/macrotasks work.",
      category: "JavaScript",
      difficulty: "hard",
      expectedAnswer: "The event loop processes macrotasks (setTimeout, I/O) one at a time, then clears all microtasks (Promises, queueMicrotask) before the next macrotask.",
    },
  ],
  "Backend Engineer": [
    {
      question: "Explain REST API design principles and best practices.",
      category: "API Design",
      difficulty: "medium",
      expectedAnswer: "Use proper HTTP methods, consistent naming, versioning, pagination, proper status codes, and HATEOAS where appropriate.",
    },
    {
      question: "How would you design a database schema for a social media application?",
      category: "Database",
      difficulty: "hard",
      expectedAnswer: "Normalize core entities (users, posts, comments), use indexes on query columns, consider read replicas, and plan for sharding at scale.",
    },
    {
      question: "Explain the differences between SQL and NoSQL databases.",
      category: "Database",
      difficulty: "easy",
      expectedAnswer: "SQL databases are structured, ACID-compliant, use schemas. NoSQL is schema-flexible, horizontally scalable, better for unstructured data.",
    },
    {
      question: "What is the difference between threads and processes?",
      category: "Operating Systems",
      difficulty: "medium",
      expectedAnswer: "Processes have separate memory spaces; threads share memory within a process. Context switching is cheaper for threads.",
    },
    {
      question: "Describe how you would implement caching in a web application.",
      category: "System Design",
      difficulty: "medium",
      expectedAnswer: "Use Redis/Memcached for hot data, CDN for static assets, database query caching, and implement cache invalidation strategies.",
    },
  ],
  "Full Stack Engineer": [
    {
      question: "Walk me through how a request flows from browser to database and back.",
      category: "System Design",
      difficulty: "medium",
      expectedAnswer: "DNS resolution → TCP handshake → HTTP request → server routing → controller logic → database query → response serialization → HTTP response.",
    },
    {
      question: "How do you handle authentication and authorization in a full-stack app?",
      category: "Security",
      difficulty: "medium",
      expectedAnswer: "Use JWT or session-based auth, implement middleware for protected routes, role-based access control, and secure token storage.",
    },
    {
      question: "Explain CORS and how to handle it in production.",
      category: "Web",
      difficulty: "easy",
      expectedAnswer: "CORS restricts cross-origin requests. Configure allowed origins, methods, and headers server-side. Use credentials option carefully.",
    },
    {
      question: "Describe the MERN stack and its advantages.",
      category: "MERN",
      difficulty: "easy",
      expectedAnswer: "MongoDB (NoSQL), Express (backend framework), React (frontend), Node.js (runtime). JavaScript end-to-end, JSON data flow, large ecosystem.",
    },
    {
      question: "How would you optimize a slow-loading web application?",
      category: "Performance",
      difficulty: "hard",
      expectedAnswer: "Code splitting, lazy loading, image optimization, caching, CDN, database indexing, query optimization, and bundle size reduction.",
    },
  ],
};

export const interviewRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.interviews.findMany({
      where: eq(interviews.userId, ctx.user.id),
      orderBy: desc(interviews.createdAt),
    });
  }),

  getById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const interview = await db.query.interviews.findFirst({
        where: and(
          eq(interviews.id, input.id),
          eq(interviews.userId, ctx.user.id),
        ),
      });
      if (!interview) return null;
      const qs = await db.query.questions.findMany({
        where: eq(questions.interviewId, input.id),
        orderBy: questions.order,
      });
      return { ...interview, questions: qs };
    }),

  create: authedQuery
    .input(
      z.object({
        role: z.string().min(1),
        difficulty: z.enum(["easy", "medium", "hard"]).default("medium"),
        type: z
          .enum([
            "hr",
            "technical",
            "behavioral",
            "problem_solving",
            "system_design",
            "mixed",
          ])
          .default("mixed"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [interviewResult] = await db
        .insert(interviews)
        .values({
          userId: ctx.user.id,
          role: input.role,
          difficulty: input.difficulty,
          type: input.type,
          status: "in_progress",
        })
        .$returningId();

      const interviewId = interviewResult.id;

      const roleQuestions =
        INTERVIEW_QUESTIONS[input.role] ||
        INTERVIEW_QUESTIONS["Full Stack Engineer"];

      const selected = roleQuestions.slice(0, 5);

      for (let i = 0; i < selected.length; i++) {
        const q = selected[i];
        await db.insert(questions).values({
          interviewId,
          category: q.category,
          difficulty: q.difficulty as "easy" | "medium" | "hard",
          question: q.question,
          expectedAnswer: q.expectedAnswer,
          order: i,
        });
      }

      // Update analytics
      const existingAnalytics = await db.query.analytics.findFirst({
        where: eq(analytics.userId, ctx.user.id),
      });
      if (existingAnalytics) {
        await db
          .update(analytics)
          .set({
            totalInterviews: existingAnalytics.totalInterviews + 1,
          })
          .where(eq(analytics.userId, ctx.user.id));
      } else {
        await db.insert(analytics).values({
          userId: ctx.user.id,
          totalInterviews: 1,
        });
      }

      return db.query.interviews.findFirst({
        where: eq(interviews.id, interviewId),
      });
    }),

  submitAnswer: authedQuery
    .input(
      z.object({
        questionId: z.number(),
        userAnswer: z.string().min(1),
        technicalScore: z.number().min(0).max(10).optional(),
        communicationScore: z.number().min(0).max(10).optional(),
        score: z.number().min(0).max(10).optional(),
        feedback: z.string().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db
        .insert(responses)
        .values({
          questionId: input.questionId,
          userAnswer: input.userAnswer,
          score: input.score ?? 7,
          feedback:
            input.feedback ??
            "Good response. Consider providing more specific examples and technical depth in your answers.",
          technicalScore: input.technicalScore ?? 7,
          communicationScore: input.communicationScore ?? 7,
        })
        .$returningId();
      return db.query.responses.findFirst({
        where: eq(responses.id, result.id),
      });
    }),

  complete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Get all questions and responses
      const qs = await db.query.questions.findMany({
        where: eq(questions.interviewId, input.id),
      });

      let totalScore = 0;
      let techScore = 0;
      let commScore = 0;
      let responseCount = 0;
      const strengths: string[] = [];
      const improvements: string[] = [];

      for (const q of qs) {
        const resp = await db.query.responses.findFirst({
          where: eq(responses.questionId, q.id),
        });
        if (resp) {
          totalScore += resp.score ?? 0;
          techScore += resp.technicalScore ?? 0;
          commScore += resp.communicationScore ?? 0;
          responseCount++;
          if ((resp.score ?? 0) >= 8) {
            strengths.push(q.category);
          } else if ((resp.score ?? 0) <= 5) {
            improvements.push(q.category);
          }
        }
      }

      const avgScore = responseCount > 0 ? Math.round(totalScore / responseCount) : 0;
      const avgTech = responseCount > 0 ? Math.round(techScore / responseCount) : 0;
      const avgComm = responseCount > 0 ? Math.round(commScore / responseCount) : 0;

      await db
        .update(interviews)
        .set({
          status: "completed",
          totalScore: avgScore,
          technicalScore: avgTech,
          communicationScore: avgComm,
          confidenceScore: avgComm,
          problemSolvingScore: avgTech,
          strengths: [...new Set(strengths)],
          improvements: [...new Set(improvements)],
          feedback: `Overall Score: ${avgScore}/10. ${avgScore >= 8 ? "Excellent performance!" : avgScore >= 6 ? "Good progress, focus on identified areas." : "Keep practicing, review fundamentals."}`,
        })
        .where(eq(interviews.id, input.id));

      // Update analytics
      const existingAnalytics = await db.query.analytics.findFirst({
        where: eq(analytics.userId, ctx.user.id),
      });
      if (existingAnalytics) {
        const newBest = Math.max(existingAnalytics.bestScore, avgScore);
        const newAvg = existingAnalytics.averageScore === 0
          ? avgScore
          : Math.round((existingAnalytics.averageScore + avgScore) / 2);
        await db
          .update(analytics)
          .set({
            bestScore: newBest,
            averageScore: newAvg,
          })
          .where(eq(analytics.userId, ctx.user.id));
      }

      return db.query.interviews.findFirst({
        where: eq(interviews.id, input.id),
      });
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .delete(interviews)
        .where(
          and(
            eq(interviews.id, input.id),
            eq(interviews.userId, ctx.user.id),
          ),
        );
      return { success: true };
    }),
});
