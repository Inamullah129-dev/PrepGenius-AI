import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  json,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users (managed by auth system) ───────────────────────────────

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Profiles ──────────────────────────────────────────────────────

export const profiles = mysqlTable("profiles", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .unique(),
  title: varchar("title", { length: 255 }),
  bio: text("bio"),
  location: varchar("location", { length: 255 }),
  linkedin: varchar("linkedin", { length: 500 }),
  github: varchar("github", { length: 500 }),
  portfolio: varchar("portfolio", { length: 500 }),
  education: json("education").$type<
    Array<{
      school: string;
      degree: string;
      field: string;
      startYear: string;
      endYear: string;
    }>
  >(),
  experience: json("experience").$type<
    Array<{
      company: string;
      role: string;
      duration: string;
      description: string;
    }>
  >(),
  skills: json("skills").$type<string[]>(),
  projects: json("projects").$type<
    Array<{
      name: string;
      description: string;
      tech: string[];
      link?: string;
    }>
  >(),
  completionScore: int("completionScore").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = typeof profiles.$inferInsert;

// ─── Resumes ───────────────────────────────────────────────────────

export const resumes = mysqlTable("resumes", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  fileUrl: varchar("fileUrl", { length: 500 }),
  fileName: varchar("fileName", { length: 255 }),
  atsScore: int("atsScore"),
  parsedData: json("parsedData").$type<{
    skills: string[];
    experience: string[];
    education: string[];
    keywords: string[];
  }>(),
  analysis: json("analysis").$type<{
    missingSkills: string[];
    formattingIssues: string[];
    suggestions: string[];
    keywordMatch: number;
    roleMatch: string;
  }>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Resume = typeof resumes.$inferSelect;
export type InsertResume = typeof resumes.$inferInsert;

// ─── Interviews ────────────────────────────────────────────────────

export const interviews = mysqlTable("interviews", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  role: varchar("role", { length: 255 }).notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"])
    .default("medium")
    .notNull(),
  type: mysqlEnum("type", [
    "hr",
    "technical",
    "behavioral",
    "problem_solving",
    "system_design",
    "mixed",
  ])
    .default("mixed")
    .notNull(),
  status: mysqlEnum("status", ["in_progress", "completed", "abandoned"])
    .default("in_progress")
    .notNull(),
  totalScore: int("totalScore"),
  technicalScore: int("technicalScore"),
  communicationScore: int("communicationScore"),
  confidenceScore: int("confidenceScore"),
  problemSolvingScore: int("problemSolvingScore"),
  feedback: text("feedback"),
  strengths: json("strengths").$type<string[]>(),
  improvements: json("improvements").$type<string[]>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Interview = typeof interviews.$inferSelect;
export type InsertInterview = typeof interviews.$inferInsert;

// ─── Questions ─────────────────────────────────────────────────────

export const questions = mysqlTable("questions", {
  id: serial("id").primaryKey(),
  interviewId: bigint("interviewId", {
    mode: "number",
    unsigned: true,
  }).notNull(),
  category: varchar("category", { length: 255 }).notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"])
    .default("medium")
    .notNull(),
  question: text("question").notNull(),
  expectedAnswer: text("expectedAnswer"),
  order: int("order").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = typeof questions.$inferInsert;

// ─── Responses ─────────────────────────────────────────────────────

export const responses = mysqlTable("responses", {
  id: serial("id").primaryKey(),
  questionId: bigint("questionId", {
    mode: "number",
    unsigned: true,
  }).notNull(),
  userAnswer: text("userAnswer").notNull(),
  score: int("score"),
  feedback: text("feedback"),
  technicalScore: int("technicalScore"),
  communicationScore: int("communicationScore"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Response = typeof responses.$inferSelect;
export type InsertResponse = typeof responses.$inferInsert;

// ─── Analytics ─────────────────────────────────────────────────────

export const analytics = mysqlTable("analytics", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .unique(),
  totalInterviews: int("totalInterviews").default(0).notNull(),
  averageScore: int("averageScore").default(0).notNull(),
  bestScore: int("bestScore").default(0).notNull(),
  atsScore: int("atsScore"),
  profileCompletion: int("profileCompletion").default(0).notNull(),
  jobReadiness: int("jobReadiness").default(0).notNull(),
  weeklyActivity: json("weeklyActivity").$type<
    Array<{ day: string; count: number }>
  >(),
  monthlyProgress: json("monthlyProgress").$type<
    Array<{ month: string; score: number }>
  >(),
  skillGrowth: json("skillGrowth").$type<
    Array<{ skill: string; score: number; trend: "up" | "down" | "stable" }>
  >(),
  weakAreas: json("weakAreas").$type<string[]>(),
  strongAreas: json("strongAreas").$type<string[]>(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = typeof analytics.$inferInsert;
