import { useState, useEffect, useRef, useCallback } from "react";

interface Message {
  id: number;
  type: "system" | "ai" | "user" | "typing";
  content: string;
  scores?: Array<{ label: string; value: number }>;
}

const SESSION_SCRIPT: Array<
  Omit<Message, "id"> & { delay?: number }
> = [
  {
    type: "system",
    content: "Starting Frontend Engineer interview — Technical Round (Medium difficulty)",
  },
  {
    type: "ai",
    content:
      "Tell me about your experience with React. How do you approach state management in large applications?",
  },
  {
    type: "user",
    content:
      "I've worked with React for 3 years. For large apps, I use a combination of Context API for global state and Zustand for complex state trees. I also follow the principle of keeping state as close to where it's used as possible.",
  },
  {
    type: "ai",
    content:
      "Good answer. You mentioned Context API and Zustand — both solid choices. To improve: mention specific challenges you've faced with state management and how you resolved them. Score: 7/10.",
    scores: [{ label: "Technical", value: 7 }],
  },
  {
    type: "ai",
    content:
      "Explain the virtual DOM and how React uses it to optimize rendering.",
  },
  {
    type: "user",
    content:
      "The virtual DOM is a lightweight JavaScript representation of the actual DOM. When state changes, React creates a new virtual DOM tree, compares it with the previous one using a diffing algorithm, and only updates the real DOM nodes that changed.",
  },
  {
    type: "ai",
    content:
      "Strong technical explanation. You covered the key concepts — virtual DOM representation, reconciliation, and selective updates. Consider mentioning the Fiber architecture for advanced interviews. Score: 9/10.",
    scores: [{ label: "Technical", value: 9 }],
  },
  {
    type: "system",
    content: "Interview session complete",
  },
];

function getScoreColor(value: number): string {
  if (value >= 8) return "success";
  if (value >= 5) return "warning";
  return "error";
}

function TerminalHeader() {
  return (
    <div className="terminal-header">
      <div className="terminal-controls">
        <span style={{ background: "#ef4444" }} />
        <span style={{ background: "#f59e0b" }} />
        <span style={{ background: "#22c55e" }} />
      </div>
      <div className="terminal-title">
        PrepGenius AI — Frontend Engineer Interview
      </div>
      <div className="terminal-status">
        <span className="status-dot" />
        LIVE
      </div>
    </div>
  );
}

function MessageBubble({ message }: { message: Message }) {
  if (message.type === "typing") {
    return (
      <div className="message typing-indicator">
        <div className="typing-dots">
          <span />
          <span />
          <span />
        </div>
      </div>
    );
  }

  if (message.type === "system") {
    return <div className="system-message">{message.content}</div>;
  }

  return (
    <div className={`message-wrapper ${message.type}`}>
      <div className={`message-bubble ${message.type}`}>{message.content}</div>
      {message.scores && message.scores.length > 0 && (
        <div className="score-row">
          {message.scores.map((score, i) => (
            <span
              key={i}
              className={`score-badge ${getScoreColor(score.value)}`}
            >
              {score.label}: {score.value}/10
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function TerminalBody({
  messages,
  isTyping,
}: {
  messages: Message[];
  isTyping: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (ref.current) {
      ref.current.scrollTop = ref.current.scrollHeight;
    }
  }, [messages, isTyping]);

  return (
    <div className="terminal-body" ref={ref}>
      {messages.map((msg) => (
        <MessageBubble key={msg.id} message={msg} />
      ))}
      {isTyping && <MessageBubble message={{ id: -1, type: "typing", content: "" }} />}
    </div>
  );
}

function TerminalProgress({ progress }: { progress: number }) {
  return (
    <div className="terminal-progress">
      <div
        className="terminal-progress-bar"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}

export default function InterviewSimulator() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [progress, setProgress] = useState(0);
  const timeoutsRef = useRef<number[]>([]);

  const addMessage = useCallback((msg: Omit<Message, "id">) => {
    setMessages((prev) => [...prev, { ...msg, id: Date.now() + Math.random() }]);
  }, []);

  const clearAllTimeouts = useCallback(() => {
    timeoutsRef.current.forEach((id) => clearTimeout(id));
    timeoutsRef.current = [];
  }, []);

  const runSession = useCallback(() => {
    clearAllTimeouts();
    setMessages([]);
    setIsTyping(false);
    setProgress(0);

    const schedule = (fn: () => void, delay: number) => {
      const id = window.setTimeout(fn, delay);
      timeoutsRef.current.push(id);
      return id;
    };

    // Session start
    schedule(() => setProgress(10), 0);
    schedule(() => setIsTyping(true), 400);
    schedule(() => {
      setIsTyping(false);
      addMessage(SESSION_SCRIPT[0]);
    }, 1000);

    // Question 1
    schedule(() => setIsTyping(true), 2000);
    schedule(() => {
      setIsTyping(false);
      addMessage(SESSION_SCRIPT[1]);
    }, 3000);

    // User response 1
    schedule(() => setProgress(30), 5000);
    schedule(() => setIsTyping(true), 7000);
    schedule(() => {
      setIsTyping(false);
      addMessage(SESSION_SCRIPT[2]);
    }, 11000);

    // AI feedback 1
    schedule(() => setIsTyping(true), 13000);
    schedule(() => {
      setIsTyping(false);
      addMessage(SESSION_SCRIPT[3]);
    }, 16000);

    // Question 2
    schedule(() => setProgress(60), 18000);
    schedule(() => setIsTyping(true), 20000);
    schedule(() => {
      setIsTyping(false);
      addMessage(SESSION_SCRIPT[4]);
    }, 24000);

    // User response 2
    schedule(() => setIsTyping(true), 26000);
    schedule(() => {
      setIsTyping(false);
      addMessage(SESSION_SCRIPT[5]);
    }, 30000);

    // AI feedback 2
    schedule(() => setProgress(85), 32000);
    schedule(() => setIsTyping(true), 34000);
    schedule(() => {
      setIsTyping(false);
      addMessage(SESSION_SCRIPT[6]);
    }, 38000);

    // Session complete
    schedule(() => setProgress(100), 42000);
    schedule(() => addMessage(SESSION_SCRIPT[7]), 43000);

    // Loop
    schedule(() => runSession(), 47000);
  }, [clearAllTimeouts, addMessage]);

  useEffect(() => {
    runSession();
    return clearAllTimeouts;
  }, []);

  return (
    <div className="simulator-wrapper">
      <div className="terminal-glow" />
      <div className="terminal terminal-tilt" style={{ willChange: "transform" }}>
        <TerminalHeader />
        <TerminalBody messages={messages} isTyping={isTyping} />
        <TerminalProgress progress={progress} />
      </div>
    </div>
  );
}
