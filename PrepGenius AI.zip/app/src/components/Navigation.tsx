import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Menu, X, Hexagon, LogOut, LayoutDashboard } from "lucide-react";

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();
  const isHome = location.pathname === "/";

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY >= 100);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
      setMobileOpen(false);
    }
  };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(10, 10, 10, 0.85)" : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled
          ? "1px solid rgba(255, 255, 255, 0.06)"
          : "1px solid transparent",
      }}
    >
      <div
        className="mx-auto flex items-center justify-between"
        style={{
          maxWidth: 1200,
          height: 64,
          padding: "0 48px",
        }}
      >
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <Hexagon className="text-[#6d5b45]" size={28} strokeWidth={1.5} />
          <span
            className="text-white font-medium"
            style={{ fontSize: 16, fontFamily: "Geist, sans-serif" }}
          >
            PrepGenius
          </span>
        </Link>

        {/* Center Nav - Desktop */}
        {isHome && (
          <div className="hidden md:flex items-center gap-8">
            {[
              { label: "Platform", action: () => scrollToSection("features") },
              { label: "Use Cases", action: () => scrollToSection("how-it-works") },
              { label: "Pricing", action: () => scrollToSection("pricing") },
              { label: "Docs", action: () => scrollToSection("testimonials") },
            ].map((item) => (
              <button
                key={item.label}
                onClick={item.action}
                className="relative text-sm font-normal transition-colors duration-200 hover:text-white"
                style={{
                  color: "rgba(255, 255, 255, 0.6)",
                  fontFamily: "Geist, sans-serif",
                  background: "none",
                  border: "none",
                }}
              >
                {item.label}
                <span
                  className="absolute bottom-0 left-0 h-px bg-[#6d5b45] transition-transform duration-250 origin-left"
                  style={{ width: "100%", transform: "scaleX(0)" }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.transform = "scaleX(1)")
                  }
                />
              </button>
            ))}
          </div>
        )}

        {/* Right Side */}
        <div className="hidden md:flex items-center gap-4">
          {isAuthenticated ? (
            <>
              <Link
                to="/dashboard"
                className="flex items-center gap-1.5 text-sm transition-colors duration-200 hover:text-white"
                style={{ color: "rgba(255, 255, 255, 0.6)" }}
              >
                <LayoutDashboard size={16} />
                Dashboard
              </Link>
              <div className="flex items-center gap-2">
                {user?.avatar ? (
                  <img
                    src={user.avatar}
                    alt={user.name || "User"}
                    className="w-7 h-7 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-[#6d5b45]/20 flex items-center justify-center">
                    <span className="text-xs text-[#8a7a62]">
                      {(user?.name || "U").charAt(0)}
                    </span>
                  </div>
                )}
                <span
                  className="text-sm"
                  style={{
                    color: "rgba(255, 255, 255, 0.6)",
                  }}
                >
                  {user?.name || "User"}
                </span>
              </div>
              <button
                onClick={logout}
                className="flex items-center gap-1 text-sm transition-colors duration-200 hover:text-white"
                style={{ color: "rgba(255, 255, 255, 0.35)" }}
              >
                <LogOut size={14} />
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="text-sm transition-colors duration-200 hover:text-white"
                style={{ color: "rgba(255, 255, 255, 0.6)" }}
              >
                Sign In
              </Link>
              <Link
                to="/login"
                className="text-sm font-medium px-5 py-2 rounded-md transition-all duration-200 hover:brightness-110"
                style={{
                  background: "#6d5b45",
                  color: "#fff",
                  fontSize: 13,
                }}
              >
                Get Started
              </Link>
            </>
          )}
        </div>

        {/* Mobile Hamburger */}
        <button
          className="md:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
          style={{ color: "rgba(255, 255, 255, 0.6)" }}
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="md:hidden"
          style={{
            background: "rgba(10, 10, 10, 0.95)",
            backdropFilter: "blur(12px)",
            borderTop: "1px solid rgba(255, 255, 255, 0.06)",
            padding: "16px 20px",
          }}
        >
          {isHome && (
            <>
              {["features", "how-it-works", "pricing", "testimonials"].map(
                (id) => (
                  <button
                    key={id}
                    onClick={() => scrollToSection(id)}
                    className="block w-full text-left py-3 text-lg"
                    style={{ color: "rgba(255, 255, 255, 0.6)" }}
                  >
                    {id.replace(/-/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                  </button>
                ),
              )}
            </>
          )}
          {isAuthenticated ? (
            <div className="flex flex-col gap-3 pt-4 border-t border-white/5">
              <Link
                to="/dashboard"
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 py-2"
                style={{ color: "rgba(255, 255, 255, 0.6)" }}
              >
                <LayoutDashboard size={18} />
                Dashboard
              </Link>
              <button
                onClick={() => {
                  logout();
                  setMobileOpen(false);
                }}
                className="flex items-center gap-2 py-2"
                style={{ color: "rgba(255, 255, 255, 0.6)" }}
              >
                <LogOut size={18} />
                Logout
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-3 pt-4 border-t border-white/5">
              <Link
                to="/login"
                onClick={() => setMobileOpen(false)}
                className="py-2"
                style={{ color: "rgba(255, 255, 255, 0.6)" }}
              >
                Sign In
              </Link>
              <Link
                to="/login"
                onClick={() => setMobileOpen(false)}
                className="py-2 px-4 rounded-md text-center font-medium"
                style={{ background: "#6d5b45", color: "#fff" }}
              >
                Get Started
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
