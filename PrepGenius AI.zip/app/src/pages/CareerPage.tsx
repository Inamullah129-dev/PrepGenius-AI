import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import Navigation from "@/components/Navigation";
import {
  ArrowLeft,
  Target,
  BookOpen,
  Award,
  CheckCircle,
  MapPin,
  ChevronRight,
  Compass,
  GraduationCap,
} from "lucide-react";

export default function CareerPage() {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const [selectedRole, setSelectedRole] = useState("Frontend Engineer");

  const { data: careerData } = trpc.career.roadmap.useQuery(
    { role: selectedRole },
    { enabled: isAuthenticated },
  );

  const { data: reportData } = trpc.career.report.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0a0a" }}>
        <div className="text-center">
          <h2 style={{ fontFamily: "'Instrument Serif', Georgia, serif", fontSize: 28, color: "#fff" }}>
            Sign in to access career coaching
          </h2>
          <button
            onClick={() => navigate("/login")}
            className="mt-4 px-6 py-3 rounded-lg font-medium"
            style={{ background: "#6d5b45", color: "#fff" }}
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const roles = ["Frontend Engineer", "Backend Engineer", "Full Stack Engineer", "Data Scientist"];

  return (
    <div className="min-h-screen" style={{ background: "#0a0a0a" }}>
      <Navigation />
      <div style={{ paddingTop: 80 }}>
        <div className="mx-auto px-6 py-8" style={{ maxWidth: 1000 }}>
          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <button
              onClick={() => navigate("/dashboard")}
              className="p-2 rounded-lg transition-colors"
              style={{ background: "rgba(255,255,255,0.05)" }}
            >
              <ArrowLeft size={18} style={{ color: "rgba(255,255,255,0.6)" }} />
            </button>
            <div>
              <h1
                style={{
                  fontFamily: "'Instrument Serif', Georgia, serif",
                  fontSize: 32,
                  fontWeight: 400,
                  color: "#fff",
                }}
              >
                Career Coach
              </h1>
              <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)" }}>
                Personalized roadmap and recommendations for your career growth
              </p>
            </div>
          </div>

          {/* Job Readiness Score */}
          {reportData && (
            <div
              className="p-6 rounded-xl mb-8"
              style={{
                background: "linear-gradient(135deg, rgba(109, 91, 69, 0.08) 0%, #151515 50%)",
                border: "1px solid rgba(109, 91, 69, 0.15)",
              }}
            >
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <div
                  className="relative flex items-center justify-center"
                  style={{ width: 100, height: 100 }}
                >
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="7" />
                    <circle
                      cx="50" cy="50" r="42" fill="none"
                      stroke={reportData.jobReadiness === "High" ? "#4ade80" : reportData.jobReadiness === "Moderate" ? "#fbbf24" : "#f87171"}
                      strokeWidth="7" strokeLinecap="round"
                      strokeDasharray={`${(reportData.readinessScore >= 80 ? reportData.readinessScore : reportData.readinessScore >= 60 ? reportData.readinessScore : 40) * 2.64} 264`}
                      transform="rotate(-90 50 50)"
                      style={{ transition: "stroke-dasharray 1s ease-out" }}
                    />
                  </svg>
                  <div className="absolute text-center">
                    <span style={{ fontFamily: "'Geist Mono', monospace", fontSize: 22, color: "#fff" }}>
                      {reportData.readinessScore}
                    </span>
                  </div>
                </div>
                <div className="flex-1 text-center sm:text-left">
                  <h3 style={{ fontSize: 18, fontWeight: 500, color: "#fff" }}>
                    Job Readiness: {reportData.jobReadiness}
                  </h3>
                  <p style={{ fontSize: 14, color: "rgba(255,255,255,0.6)", marginTop: 4 }}>
                    Based on your interview performance, skill gaps, and profile completeness
                  </p>
                </div>
                <div
                  className="px-4 py-2 rounded-lg text-sm font-medium"
                  style={{
                    background:
                      reportData.jobReadiness === "High"
                        ? "rgba(74, 222, 128, 0.1)"
                        : reportData.jobReadiness === "Moderate"
                          ? "rgba(251, 191, 36, 0.1)"
                          : "rgba(248, 113, 113, 0.1)",
                    color:
                      reportData.jobReadiness === "High"
                        ? "#4ade80"
                        : reportData.jobReadiness === "Moderate"
                          ? "#fbbf24"
                          : "#f87171",
                  }}
                >
                  {reportData.jobReadiness === "High"
                    ? "Ready to Apply"
                    : reportData.jobReadiness === "Moderate"
                      ? "Almost There"
                      : "Keep Learning"}
                </div>
              </div>
            </div>
          )}

          {/* Role Selection */}
          <div
            className="p-6 rounded-xl mb-8"
            style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <label
              className="block mb-4"
              style={{
                fontFamily: "'Geist Mono', monospace",
                fontSize: 11,
                letterSpacing: "0.05em",
                color: "rgba(255,255,255,0.5)",
                textTransform: "uppercase",
              }}
            >
              Select Target Role
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {roles.map((role) => (
                <button
                  key={role}
                  onClick={() => setSelectedRole(role)}
                  className="p-3 rounded-lg text-sm text-center transition-all"
                  style={{
                    background:
                      selectedRole === role
                        ? "rgba(109, 91, 69, 0.15)"
                        : "rgba(255,255,255,0.02)",
                    border:
                      selectedRole === role
                        ? "1px solid rgba(109, 91, 69, 0.4)"
                        : "1px solid rgba(255,255,255,0.06)",
                    color: selectedRole === role ? "#fff" : "rgba(255,255,255,0.5)",
                  }}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>

          {/* Career Roadmap */}
          {careerData && (
            <div className="mb-8">
              <h2
                className="mb-6 flex items-center gap-2"
                style={{ fontSize: 20, fontWeight: 500, color: "#fff" }}
              >
                <Compass size={20} style={{ color: "#6d5b45" }} />
                Career Roadmap: {selectedRole}
              </h2>
              <div className="space-y-4">
                {careerData.milestones.map((milestone, i) => (
                  <div
                    key={i}
                    className="relative pl-8 pb-4"
                    style={{
                      borderLeft:
                        i < careerData.milestones.length - 1
                          ? "2px solid rgba(109, 91, 69, 0.3)"
                          : "none",
                    }}
                  >
                    {/* Dot */}
                    <div
                      className="absolute left-0 top-0 flex items-center justify-center"
                      style={{
                        width: 16,
                        height: 16,
                        marginLeft: -9,
                        borderRadius: "50%",
                        background: "#151515",
                        border: "2px solid #6d5b45",
                      }}
                    >
                      <span
                        style={{
                          fontSize: 9,
                          fontFamily: "'Geist Mono', monospace",
                          color: "#6d5b45",
                        }}
                      >
                        {i + 1}
                      </span>
                    </div>

                    <div
                      className="p-5 rounded-xl"
                      style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-2">
                        <h3 style={{ fontSize: 16, fontWeight: 500, color: "#fff" }}>
                          {milestone.title}
                        </h3>
                        <span
                          className="sm:ml-auto px-2 py-0.5 rounded text-xs"
                          style={{
                            background: "rgba(109, 91, 69, 0.1)",
                            color: "#8a7a62",
                          }}
                        >
                          {milestone.duration}
                        </span>
                      </div>
                      <p style={{ fontSize: 14, color: "rgba(255,255,255,0.6)", marginBottom: 12 }}>
                        {milestone.description}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {milestone.skills.map((skill) => (
                          <span
                            key={skill}
                            className="px-2.5 py-1 rounded text-xs"
                            style={{
                              background: "rgba(255,255,255,0.05)",
                              color: "rgba(255,255,255,0.6)",
                              border: "1px solid rgba(255,255,255,0.06)",
                            }}
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Two Column: Certifications & Recommendations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Certifications */}
            {careerData?.certifications && (
              <div
                className="p-6 rounded-xl"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <h3
                  className="flex items-center gap-2 mb-4"
                  style={{ fontSize: 16, fontWeight: 500, color: "#fff" }}
                >
                  <GraduationCap size={18} style={{ color: "#a78bfa" }} />
                  Recommended Certifications
                </h3>
                <div className="space-y-3">
                  {careerData.certifications.map((cert) => (
                    <div
                      key={cert}
                      className="flex items-center gap-3 p-3 rounded-lg"
                      style={{ background: "rgba(255,255,255,0.02)" }}
                    >
                      <Award size={16} style={{ color: "#a78bfa" }} />
                      <span style={{ fontSize: 14, color: "rgba(255,255,255,0.8)" }}>
                        {cert}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recommendations */}
            {careerData?.recommendations && (
              <div
                className="p-6 rounded-xl"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <h3
                  className="flex items-center gap-2 mb-4"
                  style={{ fontSize: 16, fontWeight: 500, color: "#fff" }}
                >
                  <BookOpen size={18} style={{ color: "#60a5fa" }} />
                  Action Items
                </h3>
                <div className="space-y-3">
                  {careerData.recommendations.map((rec, i) => (
                    <div
                      key={i}
                      className="flex items-start gap-3 p-3 rounded-lg"
                      style={{ background: "rgba(255,255,255,0.02)" }}
                    >
                      <CheckCircle size={16} style={{ color: "#4ade80", marginTop: 2 }} />
                      <span style={{ fontSize: 14, color: "rgba(255,255,255,0.8)" }}>
                        {rec}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Skill Gaps & Next Steps */}
          {reportData && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div
                className="p-6 rounded-xl"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <h3
                  className="flex items-center gap-2 mb-4"
                  style={{ fontSize: 16, fontWeight: 500, color: "#fbbf24" }}
                >
                  <Target size={18} /> Priority Skill Gaps
                </h3>
                <div className="space-y-3">
                  {reportData.skillGaps.map((gap) => (
                    <div
                      key={gap.skill}
                      className="flex items-center justify-between p-3 rounded-lg"
                      style={{ background: "rgba(255,255,255,0.02)" }}
                    >
                      <span style={{ fontSize: 14, color: "rgba(255,255,255,0.8)" }}>
                        {gap.skill}
                      </span>
                      <span
                        className="px-2 py-0.5 rounded text-xs font-medium"
                        style={{
                          background:
                            gap.priority === "high"
                              ? "rgba(248, 113, 113, 0.1)"
                              : gap.priority === "medium"
                                ? "rgba(251, 191, 36, 0.1)"
                                : "rgba(74, 222, 128, 0.1)",
                          color:
                            gap.priority === "high"
                              ? "#f87171"
                              : gap.priority === "medium"
                                ? "#fbbf24"
                                : "#4ade80",
                        }}
                      >
                        {gap.priority}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div
                className="p-6 rounded-xl"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <h3
                  className="flex items-center gap-2 mb-4"
                  style={{ fontSize: 16, fontWeight: 500, color: "#4ade80" }}
                >
                  <MapPin size={18} /> Next Steps
                </h3>
                <div className="space-y-3">
                  {reportData.nextSteps.map((step, i) => (
                    <div
                      key={i}
                      className="flex items-start gap-3 p-3 rounded-lg"
                      style={{ background: "rgba(255,255,255,0.02)" }}
                    >
                      <span
                        className="flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-xs font-medium"
                        style={{
                          background: "rgba(109, 91, 69, 0.15)",
                          color: "#6d5b45",
                        }}
                      >
                        {i + 1}
                      </span>
                      <span style={{ fontSize: 14, color: "rgba(255,255,255,0.8)" }}>
                        {step}
                      </span>
                      <ChevronRight
                        size={14}
                        className="flex-shrink-0 mt-0.5"
                        style={{ color: "rgba(255,255,255,0.3)" }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
