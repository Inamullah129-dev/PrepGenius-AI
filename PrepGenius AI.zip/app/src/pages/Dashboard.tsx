import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import Navigation from "@/components/Navigation";
import {
  Mic,
  FileText,
  TrendingUp,
  Award,
  Target,
  ArrowRight,
  BarChart3,
  Zap,
  AlertCircle,
} from "lucide-react";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [skillBarsAnimated, setSkillBarsAnimated] = useState(false);
  const chartRef = useRef<HTMLDivElement>(null);

  const { data: dashboardData } =
    trpc.analytics.dashboard.useQuery(undefined, {
      enabled: isAuthenticated,
    });

  const { data: progressData } = trpc.analytics.progress.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: interviewsList } = trpc.interview.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate("/login");
    }
  }, [authLoading, isAuthenticated, navigate]);

  useEffect(() => {
    if (chartRef.current) {
      const timer = setTimeout(() => setSkillBarsAnimated(true), 300);
      return () => clearTimeout(timer);
    }
  }, [dashboardData]);

  if (authLoading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "#0a0a0a" }}
      >
        <div className="animate-spin w-8 h-8 border-2 border-[#6d5b45] border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) return null;

  const stats = dashboardData?.stats ?? {
    totalInterviews: 0,
    averageScore: 0,
    bestScore: 0,
    atsScore: 0,
    profileCompletion: 0,
    jobReadiness: 0,
  };

  const statCards = [
    {
      label: "Total Interviews",
      value: stats.totalInterviews,
      icon: <Mic size={20} />,
      color: "#6d5b45",
    },
    {
      label: "Average Score",
      value: stats.averageScore > 0 ? `${stats.averageScore}/10` : "—",
      icon: <BarChart3 size={20} />,
      color: "#60a5fa",
    },
    {
      label: "Best Score",
      value: stats.bestScore > 0 ? `${stats.bestScore}/10` : "—",
      icon: <Award size={20} />,
      color: "#4ade80",
    },
    {
      label: "ATS Score",
      value: stats.atsScore > 0 ? `${stats.atsScore}%` : "—",
      icon: <FileText size={20} />,
      color: "#a78bfa",
    },
  ];

  return (
    <div className="min-h-screen" style={{ background: "#0a0a0a" }}>
      <Navigation />
      <div style={{ paddingTop: 80 }}>
        <div className="mx-auto px-6 py-8" style={{ maxWidth: 1200 }}>
          {/* Header */}
          <div className="mb-8">
            <h1
              style={{
                fontFamily: "'Instrument Serif', Georgia, serif",
                fontSize: "clamp(28px, 3vw, 40px)",
                fontWeight: 400,
                color: "#fff",
              }}
            >
              Dashboard
            </h1>
            <p
              className="mt-1"
              style={{
                fontFamily: "Geist, sans-serif",
                fontWeight: 300,
                fontSize: 15,
                color: "rgba(255,255,255,0.6)",
              }}
            >
              Welcome back, {user?.name || "Candidate"}. Here's your progress.
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {statCards.map((stat) => (
              <div
                key={stat.label}
                className="p-5 rounded-xl"
                style={{
                  background: "#151515",
                  border: "1px solid rgba(255,255,255,0.08)",
                }}
              >
                <div className="flex items-center justify-between mb-3">
                  <span
                    style={{
                      fontSize: 13,
                      color: "rgba(255,255,255,0.6)",
                    }}
                  >
                    {stat.label}
                  </span>
                  <span style={{ color: stat.color }}>{stat.icon}</span>
                </div>
                <span
                  style={{
                    fontFamily: "'Instrument Serif', Georgia, serif",
                    fontSize: 32,
                    fontWeight: 400,
                    color: "#fff",
                  }}
                >
                  {stat.value}
                </span>
              </div>
            ))}
          </div>

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Performance Chart */}
            <div
              className="lg:col-span-2 p-6 rounded-xl"
              style={{
                background: "#151515",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <h3
                className="mb-4"
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 500,
                  fontSize: 16,
                  color: "#fff",
                }}
              >
                Performance Over Time
              </h3>
              <div ref={chartRef} className="h-48">
                {dashboardData?.monthlyProgress &&
                dashboardData.monthlyProgress.some((m) => m.score > 0) ? (
                  <svg viewBox="0 0 500 150" className="w-full h-full">
                    <defs>
                      <linearGradient
                        id="dashChartGrad"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="0%"
                          stopColor="#6d5b45"
                          stopOpacity="0.15"
                        />
                        <stop
                          offset="100%"
                          stopColor="#6d5b45"
                          stopOpacity="0"
                        />
                      </linearGradient>
                      <linearGradient
                        id="dashLineGrad"
                        x1="0"
                        y1="0"
                        x2="1"
                        y2="0"
                      >
                        <stop offset="0%" stopColor="#6d5b45" />
                        <stop offset="100%" stopColor="#8a7a62" />
                      </linearGradient>
                    </defs>
                    {/* Grid */}
                    {[0, 50, 100].map((y) => (
                      <line
                        key={y}
                        x1="0"
                        y1={40 + y}
                        x2="500"
                        y2={40 + y}
                        stroke="rgba(255,255,255,0.04)"
                        strokeWidth="1"
                        strokeDasharray="4 4"
                      />
                    ))}
                    {/* Area */}
                    <path
                      d={`M0,${140 - (dashboardData.monthlyProgress[0]?.score || 0) * 10} ${dashboardData.monthlyProgress.map((m, i) => `L${(i / (dashboardData.monthlyProgress.length - 1)) * 500},${140 - m.score * 10}`).join(" ")} L500,140 L0,140 Z`}
                      fill="url(#dashChartGrad)"
                    />
                    {/* Line */}
                    <path
                      d={`M0,${140 - (dashboardData.monthlyProgress[0]?.score || 0) * 10} ${dashboardData.monthlyProgress.map((m, i) => `L${(i / (dashboardData.monthlyProgress.length - 1)) * 500},${140 - m.score * 10}`).join(" ")}`}
                      fill="none"
                      stroke="url(#dashLineGrad)"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                    {/* Labels */}
                    {dashboardData.monthlyProgress.map((m, i) => (
                      <text
                        key={m.month}
                        x={(i / (dashboardData.monthlyProgress.length - 1)) * 500}
                        y={148}
                        fill="rgba(255,255,255,0.35)"
                        fontSize="10"
                        fontFamily="'Geist Mono', monospace"
                        textAnchor="middle"
                      >
                        {m.month}
                      </text>
                    ))}
                  </svg>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center">
                    <TrendingUp
                      size={32}
                      className="mb-2"
                      style={{ color: "rgba(255,255,255,0.2)" }}
                    />
                    <p
                      style={{
                        fontSize: 14,
                        color: "rgba(255,255,255,0.4)",
                      }}
                    >
                      Complete interviews to see your performance trend
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-4">
              <div
                className="p-6 rounded-xl"
                style={{
                  background: "#151515",
                  border: "1px solid rgba(255,255,255,0.08)",
                }}
              >
                <h3
                  className="mb-4"
                  style={{
                    fontFamily: "Geist, sans-serif",
                    fontWeight: 500,
                    fontSize: 16,
                    color: "#fff",
                  }}
                >
                  Quick Actions
                </h3>
                <div className="space-y-3">
                  {[
                    {
                      label: "Start Mock Interview",
                      desc: "Practice with AI",
                      icon: <Mic size={18} />,
                      action: () => navigate("/interview"),
                      color: "#6d5b45",
                    },
                    {
                      label: "Analyze Resume",
                      desc: "Check ATS score",
                      icon: <FileText size={18} />,
                      action: () => navigate("/resume"),
                      color: "#a78bfa",
                    },
                    {
                      label: "Career Roadmap",
                      desc: "Plan your growth",
                      icon: <Target size={18} />,
                      action: () => navigate("/career"),
                      color: "#60a5fa",
                    },
                    {
                      label: "Update Profile",
                      desc: "Complete your info",
                      icon: <Zap size={18} />,
                      action: () => navigate("/profile"),
                      color: "#4ade80",
                    },
                  ].map((item) => (
                    <button
                      key={item.label}
                      onClick={item.action}
                      className="w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors"
                      style={{
                        background: "rgba(255,255,255,0.02)",
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background =
                          "rgba(255,255,255,0.05)";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background =
                          "rgba(255,255,255,0.02)";
                      }}
                    >
                      <div
                        className="flex items-center justify-center w-9 h-9 rounded-lg"
                        style={{ background: `${item.color}15`, color: item.color }}
                      >
                        {item.icon}
                      </div>
                      <div className="flex-1">
                        <p
                          style={{
                            fontSize: 14,
                            fontWeight: 500,
                            color: "#fff",
                          }}
                        >
                          {item.label}
                        </p>
                        <p
                          style={{
                            fontSize: 12,
                            color: "rgba(255,255,255,0.4)",
                          }}
                        >
                          {item.desc}
                        </p>
                      </div>
                      <ArrowRight
                        size={14}
                        style={{ color: "rgba(255,255,255,0.3)" }}
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            {/* Recent Interviews */}
            <div
              className="p-6 rounded-xl"
              style={{
                background: "#151515",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3
                  style={{
                    fontFamily: "Geist, sans-serif",
                    fontWeight: 500,
                    fontSize: 16,
                    color: "#fff",
                  }}
                >
                  Recent Interviews
                </h3>
                <button
                  onClick={() => navigate("/interview")}
                  className="text-sm flex items-center gap-1 transition-colors hover:text-white"
                  style={{ color: "#6d5b45" }}
                >
                  View All <ArrowRight size={14} />
                </button>
              </div>

              {interviewsList && interviewsList.length > 0 ? (
                <div className="space-y-3">
                  {interviewsList.slice(0, 5).map((iv) => (
                    <div
                      key={iv.id}
                      className="flex items-center justify-between py-2"
                      style={{
                        borderBottom: "1px solid rgba(255,255,255,0.04)",
                      }}
                    >
                      <div>
                        <p style={{ fontSize: 14, color: "#fff" }}>
                          {iv.role}
                        </p>
                        <p
                          style={{
                            fontSize: 12,
                            color: "rgba(255,255,255,0.4)",
                          }}
                        >
                          {iv.type} · {iv.difficulty}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span
                          className="px-2 py-0.5 rounded text-xs font-medium"
                          style={{
                            background:
                              iv.status === "completed"
                                ? "rgba(74, 222, 128, 0.1)"
                                : "rgba(251, 191, 36, 0.1)",
                            color:
                              iv.status === "completed"
                                ? "#4ade80"
                                : "#fbbf24",
                          }}
                        >
                          {iv.status}
                        </span>
                        {iv.totalScore !== null && (
                          <span
                            className="px-2 py-0.5 rounded text-xs font-medium"
                            style={{
                              background:
                                iv.totalScore >= 8
                                  ? "rgba(74, 222, 128, 0.1)"
                                  : iv.totalScore >= 6
                                    ? "rgba(251, 191, 36, 0.1)"
                                    : "rgba(248, 113, 113, 0.1)",
                              color:
                                iv.totalScore >= 8
                                  ? "#4ade80"
                                  : iv.totalScore >= 6
                                    ? "#fbbf24"
                                    : "#f87171",
                            }}
                          >
                            {iv.totalScore}/10
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Mic
                    size={24}
                    className="mx-auto mb-2"
                    style={{ color: "rgba(255,255,255,0.2)" }}
                  />
                  <p
                    style={{
                      fontSize: 14,
                      color: "rgba(255,255,255,0.4)",
                    }}
                  >
                    No interviews yet. Start your first mock interview!
                  </p>
                  <button
                    onClick={() => navigate("/interview")}
                    className="mt-3 px-4 py-2 rounded-lg text-sm font-medium"
                    style={{ background: "#6d5b45", color: "#fff" }}
                  >
                    Start Interview
                  </button>
                </div>
              )}
            </div>

            {/* Skill Breakdown */}
            <div
              className="p-6 rounded-xl"
              style={{
                background: "#151515",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <h3
                className="mb-4"
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 500,
                  fontSize: 16,
                  color: "#fff",
                }}
              >
                Skill Breakdown
              </h3>
              {dashboardData?.skillBreakdown &&
              dashboardData.skillBreakdown.some((s) => s.score > 0) ? (
                <div className="space-y-4">
                  {dashboardData.skillBreakdown.map((skill) => (
                    <div key={skill.name}>
                      <div className="flex justify-between mb-1.5">
                        <span
                          style={{
                            fontSize: 13,
                            color: "rgba(255,255,255,0.6)",
                          }}
                        >
                          {skill.name}
                        </span>
                        <span
                          style={{
                            fontFamily: "'Geist Mono', monospace",
                            fontSize: 12,
                            color: "rgba(255,255,255,0.4)",
                          }}
                        >
                          {skill.score}%
                        </span>
                      </div>
                      <div
                        style={{
                          height: 6,
                          borderRadius: 3,
                          background: "rgba(255,255,255,0.06)",
                          overflow: "hidden",
                        }}
                      >
                        <div
                          style={{
                            height: "100%",
                            borderRadius: 3,
                            background:
                              skill.name === "Technical"
                                ? "#4ade80"
                                : skill.name === "Communication"
                                  ? "#60a5fa"
                                  : skill.name === "Problem Solving"
                                    ? "#a78bfa"
                                    : "#fbbf24",
                            width: skillBarsAnimated
                              ? `${skill.score}%`
                              : "0%",
                            transition: "width 0.8s ease-out",
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <AlertCircle
                    size={24}
                    className="mx-auto mb-2"
                    style={{ color: "rgba(255,255,255,0.2)" }}
                  />
                  <p
                    style={{
                      fontSize: 14,
                      color: "rgba(255,255,255,0.4)",
                    }}
                  >
                    Complete interviews to see your skill breakdown
                  </p>
                </div>
              )}

              {/* Career Recommendations */}
              {progressData && (
                <div className="mt-6 pt-4" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
                  <h4
                    className="mb-3"
                    style={{
                      fontSize: 14,
                      fontWeight: 500,
                      color: "#fff",
                    }}
                  >
                    Focus Areas
                  </h4>
                  <div className="space-y-2">
                    {progressData.weakAreas.map((area) => (
                      <div
                        key={area}
                        className="flex items-center gap-2 px-3 py-2 rounded-md"
                        style={{ background: "rgba(248, 113, 113, 0.06)" }}
                      >
                        <Target size={12} style={{ color: "#f87171" }} />
                        <span style={{ fontSize: 12, color: "rgba(255,255,255,0.7)" }}>
                          {area}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
