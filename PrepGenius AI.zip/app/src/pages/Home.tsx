import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import InterviewSimulator from "@/components/InterviewSimulator";
import Navigation from "@/components/Navigation";
import CustomCursor from "@/components/CustomCursor";
import {
  Mic,
  FileSearch,
  BarChart3,
  Target,
  Play,
  Check,
  ArrowRight,
  Quote,
  Hexagon,
} from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  return (
    <div style={{ background: "#0a0a0a", minHeight: "100vh" }}>
      <CustomCursor />
      <Navigation />
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <DashboardPreviewSection />
      <TestimonialsSection />
      <PricingSection />
      <CTASection />
      <Footer />
    </div>
  );
}

/* ─── Hero Section ─────────────────────────────────────────────── */

function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const trustRef = useRef<HTMLDivElement>(null);
  const terminalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({ defaults: { ease: "power3.out" } });

    tl.fromTo(
      labelRef.current,
      { opacity: 0 },
      { opacity: 1, duration: 0.4 },
      0.2,
    );

    if (headingRef.current) {
      const lines = headingRef.current.querySelectorAll(".hero-line");
      tl.fromTo(
        lines,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1.0, stagger: 0.15 },
        0.4,
      );
    }

    tl.fromTo(
      subRef.current,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.8 },
      0.9,
    );

    tl.fromTo(
      ctaRef.current,
      { opacity: 0 },
      { opacity: 1, duration: 0.6 },
      1.2,
    );

    tl.fromTo(
      trustRef.current,
      { opacity: 0 },
      { opacity: 1, duration: 0.6 },
      1.4,
    );

    tl.fromTo(
      terminalRef.current,
      { opacity: 0, x: 60 },
      { opacity: 1, x: 0, duration: 1.0 },
      0.6,
    );

    return () => {
      tl.kill();
    };
  }, []);

  return (
    <section
      ref={heroRef}
      className="relative flex items-center overflow-hidden"
      style={{
        minHeight: "100vh",
        padding: "120px 48px 80px",
        background:
          "radial-gradient(ellipse 600px 500px at 35% 50%, rgba(109, 91, 69, 0.12) 0%, transparent 70%), #0a0a0a",
      }}
    >
      <div
        className="mx-auto w-full flex flex-col lg:flex-row items-center gap-12 lg:gap-0"
        style={{ maxWidth: 1200 }}
      >
        {/* Left Column */}
        <div className="w-full lg:w-[40%] lg:pr-16">
          {/* Label */}
          <div ref={labelRef} className="flex items-center gap-2 mb-6 opacity-0">
            <span
              className="inline-block w-1.5 h-1.5 rounded-full bg-[#6d5b45]"
              style={{ animation: "pulse 2s ease-in-out infinite" }}
            />
            <span
              style={{
                fontFamily: "'Geist Mono', monospace",
                fontSize: 11,
                letterSpacing: "0.08em",
                color: "rgba(255,255,255,0.35)",
              }}
            >
              AI INTERVIEW SIMULATOR
            </span>
          </div>

          {/* Heading */}
          <div ref={headingRef}>
            <h1
              className="hero-line opacity-0"
              style={{
                fontFamily: "'Instrument Serif', Georgia, serif",
                fontSize: "clamp(40px, 6vw, 88px)",
                fontWeight: 400,
                lineHeight: 0.95,
                letterSpacing: "-0.03em",
                color: "#fff",
              }}
            >
              Ace Your Next
            </h1>
            <h1
              className="hero-line opacity-0"
              style={{
                fontFamily: "'Instrument Serif', Georgia, serif",
                fontSize: "clamp(40px, 6vw, 88px)",
                fontWeight: 400,
                lineHeight: 0.95,
                letterSpacing: "-0.03em",
                color: "#fff",
              }}
            >
              Interview.
            </h1>
          </div>

          {/* Subheading */}
          <p
            ref={subRef}
            className="opacity-0 mt-6"
            style={{
              fontFamily: "Geist, sans-serif",
              fontWeight: 300,
              fontSize: 18,
              lineHeight: 1.6,
              color: "rgba(255,255,255,0.6)",
              maxWidth: 420,
            }}
          >
            Practice with AI-generated mock interviews tailored to your target
            role. Get real-time feedback, detailed performance analytics, and
            personalized improvement recommendations.
          </p>

          {/* CTAs */}
          <div ref={ctaRef} className="flex gap-4 mt-10 opacity-0">
            <Link
              to="/interview"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-medium transition-all duration-200 hover:-translate-y-0.5"
              style={{
                background: "#6d5b45",
                color: "#fff",
                fontSize: 15,
                boxShadow: "0 4px 20px rgba(109, 91, 69, 0.25)",
              }}
            >
              Start Practicing
            </Link>
            <button
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-normal transition-all duration-200"
              style={{
                border: "1px solid rgba(255,255,255,0.08)",
                color: "rgba(255,255,255,0.6)",
                fontSize: 15,
                background: "transparent",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)";
                e.currentTarget.style.background = "rgba(255,255,255,0.03)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)";
                e.currentTarget.style.background = "transparent";
              }}
            >
              <Play size={14} fill="currentColor" />
              Watch Demo
            </button>
          </div>

          {/* Trust Bar */}
          <div ref={trustRef} className="mt-12 opacity-0">
            <p
              style={{
                fontFamily: "Geist, sans-serif",
                fontWeight: 300,
                fontSize: 13,
                color: "rgba(255,255,255,0.35)",
                marginBottom: 12,
              }}
            >
              Trusted by 10,000+ candidates at
            </p>
            <div className="flex items-center gap-6 flex-wrap">
              {["Google", "Meta", "Amazon", "Netflix", "Stripe"].map(
                (name) => (
                  <span
                    key={name}
                    style={{
                      fontFamily: "Geist, sans-serif",
                      fontWeight: 500,
                      fontSize: 15,
                      color: "rgba(255,255,255,0.2)",
                      letterSpacing: "0.02em",
                    }}
                  >
                    {name}
                  </span>
                ),
              )}
            </div>
          </div>
        </div>

        {/* Right Column - Terminal */}
        <div
          ref={terminalRef}
          className="w-full lg:w-[60%] flex justify-center opacity-0"
        >
          <InterviewSimulator />
        </div>
      </div>
    </section>
  );
}

/* ─── Features Section ─────────────────────────────────────────── */

function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sectionRef.current) return;
    const cards = sectionRef.current.querySelectorAll(".feature-card");
    gsap.fromTo(
      cards,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.7,
        stagger: 0.12,
        ease: "power3.out",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 80%",
        },
      },
    );
    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  const features = [
    {
      icon: <Mic size={20} strokeWidth={1.5} />,
      title: "AI Interview Simulator",
      description:
        "Practice with realistic mock interviews generated for your specific role and experience level. Voice or text-based responses with instant AI feedback.",
    },
    {
      icon: <FileSearch size={20} strokeWidth={1.5} />,
      title: "Resume ATS Analysis",
      description:
        "Upload your resume and get a detailed ATS compatibility score. Identify missing keywords, formatting issues, and optimization opportunities.",
    },
    {
      icon: <BarChart3 size={20} strokeWidth={1.5} />,
      title: "Performance Analytics",
      description:
        "Track your progress over time with detailed metrics — technical accuracy, communication clarity, confidence scoring, and comparative benchmarks.",
    },
    {
      icon: <Target size={20} strokeWidth={1.5} />,
      title: "Personalized Coaching",
      description:
        "Receive tailored improvement recommendations based on your performance patterns. Focus your study time on the areas that matter most.",
    },
  ];

  return (
    <section
      id="features"
      ref={sectionRef}
      style={{
        background: "#0a0a0a",
        padding: "120px 48px",
      }}
    >
      <div className="mx-auto" style={{ maxWidth: 1200 }}>
        {/* Header */}
        <div style={{ marginBottom: 64 }}>
          <span
            style={{
              fontFamily: "'Geist Mono', monospace",
              fontSize: 11,
              letterSpacing: "0.08em",
              color: "rgba(255,255,255,0.35)",
              textTransform: "uppercase",
            }}
          >
            PLATFORM CAPABILITIES
          </span>
          <h2
            style={{
              fontFamily: "'Instrument Serif', Georgia, serif",
              fontSize: "clamp(32px, 4vw, 56px)",
              fontWeight: 400,
              color: "#fff",
              maxWidth: 600,
              marginTop: 16,
              lineHeight: 1.05,
              letterSpacing: "-0.02em",
            }}
          >
            Everything you need to interview with confidence.
          </h2>
          <p
            style={{
              fontFamily: "Geist, sans-serif",
              fontWeight: 300,
              fontSize: 18,
              color: "rgba(255,255,255,0.6)",
              maxWidth: 540,
              marginTop: 20,
              lineHeight: 1.6,
            }}
          >
            From AI-powered mock interviews to detailed performance analytics,
            PrepGenius gives you the tools to identify weaknesses and turn them
            into strengths.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((f, i) => (
            <div
              key={i}
              className="feature-card group relative overflow-hidden"
              style={{
                background: "#151515",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 14,
                padding: 40,
                transition: "all 0.3s",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)";
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow =
                  "0 8px 32px rgba(0,0,0,0.3)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)";
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "none";
              }}
            >
              <div className="absolute inset-x-0 bottom-0 h-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
              {/* Icon */}
              <div
                className="flex items-center justify-center"
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: "50%",
                  background: "rgba(109, 91, 69, 0.1)",
                  color: "#6d5b45",
                }}
              >
                {f.icon}
              </div>
              <h3
                className="mt-6"
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 500,
                  fontSize: 20,
                  color: "#fff",
                }}
              >
                {f.title}
              </h3>
              <p
                className="mt-3"
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 300,
                  fontSize: 15,
                  color: "rgba(255,255,255,0.6)",
                  lineHeight: 1.6,
                }}
              >
                {f.description}
              </p>
              <span
                className="inline-flex items-center gap-1 mt-5 group/link"
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 400,
                  fontSize: 14,
                  color: "#6d5b45",
                }}
              >
                Learn more
                <ArrowRight
                  size={14}
                  className="transition-transform duration-200 group-hover/link:translate-x-1"
                />
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── How It Works Section ────────────────────────────────────── */

function HowItWorksSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sectionRef.current) return;
    const steps = sectionRef.current.querySelectorAll(".step-item");
    gsap.fromTo(
      steps,
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 0.7,
        stagger: 0.15,
        ease: "power3.out",
        scrollTrigger: { trigger: sectionRef.current, start: "top 75%" },
      },
    );
    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  const steps = [
    {
      num: "01",
      title: "Upload & Analyze",
      desc: "Upload your resume for ATS scoring and skill gap analysis. Our AI identifies your strengths and areas for improvement.",
    },
    {
      num: "02",
      title: "Configure Interview",
      desc: "Select your target role, experience level, and interview type. The AI generates tailored questions matching real interview patterns.",
    },
    {
      num: "03",
      title: "Practice & Respond",
      desc: "Answer questions via voice or text. Get real-time transcription, follow-up questions, and natural conversation flow.",
    },
    {
      num: "04",
      title: "Review & Improve",
      desc: "Receive detailed scoring across multiple dimensions with specific feedback and a personalized study plan for your next session.",
    },
  ];

  return (
    <section
      id="how-it-works"
      ref={sectionRef}
      style={{ background: "#151515", padding: "120px 48px" }}
    >
      <div className="mx-auto" style={{ maxWidth: 1200 }}>
        <span
          style={{
            fontFamily: "'Geist Mono', monospace",
            fontSize: 11,
            letterSpacing: "0.08em",
            color: "rgba(255,255,255,0.35)",
            textTransform: "uppercase",
          }}
        >
          HOW IT WORKS
        </span>
        <h2
          style={{
            fontFamily: "'Instrument Serif', Georgia, serif",
            fontSize: "clamp(32px, 4vw, 56px)",
            fontWeight: 400,
            color: "#fff",
            maxWidth: 500,
            marginTop: 16,
            lineHeight: 1.05,
            letterSpacing: "-0.02em",
          }}
        >
          Four steps to interview mastery.
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mt-16">
          {steps.map((s, i) => (
            <div key={i} className="step-item relative">
              <span
                style={{
                  fontFamily: "'Geist Mono', monospace",
                  fontSize: 48,
                  color: "rgba(255,255,255,0.08)",
                  fontWeight: 400,
                  lineHeight: 1,
                }}
              >
                {s.num}
              </span>
              <h3
                className="mt-5"
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 500,
                  fontSize: 20,
                  color: "#fff",
                }}
              >
                {s.title}
              </h3>
              <p
                className="mt-3"
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 300,
                  fontSize: 15,
                  color: "rgba(255,255,255,0.6)",
                  lineHeight: 1.6,
                }}
              >
                {s.desc}
              </p>
              {i < 3 && (
                <div
                  className="hidden md:block absolute top-6 -right-4"
                  style={{
                    width: 32,
                    height: 1,
                    background:
                      "repeating-linear-gradient(90deg, rgba(255,255,255,0.08) 0, rgba(255,255,255,0.08) 4px, transparent 4px, transparent 8px)",
                  }}
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Dashboard Preview Section ────────────────────────────────── */

function DashboardPreviewSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [skillBarsAnimated, setSkillBarsAnimated] = useState(false);

  useEffect(() => {
    if (!sectionRef.current || !containerRef.current) return;
    gsap.fromTo(
      containerRef.current,
      { opacity: 0, y: 50 },
      {
        opacity: 1,
        y: 0,
        duration: 0.9,
        ease: "power3.out",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 80%",
          onEnter: () => setSkillBarsAnimated(true),
        },
      },
    );
    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  const skillBreakdown = [
    { name: "Technical", score: 85, color: "#4ade80" },
    { name: "Communication", score: 72, color: "#60a5fa" },
    { name: "Problem Solving", score: 78, color: "#a78bfa" },
    { name: "Confidence", score: 68, color: "#fbbf24" },
  ];

  const recentSessions = [
    { role: "Frontend Engineer", date: "Jun 10, 2026", score: 8 },
    { role: "Full Stack Developer", date: "Jun 8, 2026", score: 7 },
    { role: "Backend Engineer", date: "Jun 5, 2026", score: 9 },
  ];

  return (
    <section
      ref={sectionRef}
      style={{ background: "#0a0a0a", padding: "120px 48px" }}
    >
      <div className="mx-auto" style={{ maxWidth: 1200 }}>
        <span
          style={{
            fontFamily: "'Geist Mono', monospace",
            fontSize: 11,
            letterSpacing: "0.08em",
            color: "rgba(255,255,255,0.35)",
            textTransform: "uppercase",
          }}
        >
          ANALYTICS DASHBOARD
        </span>
        <h2
          style={{
            fontFamily: "'Instrument Serif', Georgia, serif",
            fontSize: "clamp(32px, 4vw, 56px)",
            fontWeight: 400,
            color: "#fff",
            maxWidth: 500,
            marginTop: 16,
            lineHeight: 1.05,
            letterSpacing: "-0.02em",
          }}
        >
          Track every metric that matters.
        </h2>
        <p
          style={{
            fontFamily: "Geist, sans-serif",
            fontWeight: 300,
            fontSize: 18,
            color: "rgba(255,255,255,0.6)",
            maxWidth: 480,
            marginTop: 16,
            lineHeight: 1.6,
          }}
        >
          Comprehensive performance insights help you understand exactly where
          you stand and what to focus on next.
        </p>

        {/* Dashboard Container */}
        <div
          ref={containerRef}
          className="mt-16 overflow-hidden"
          style={{
            background: "#151515",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 14,
            boxShadow: "0 32px 64px rgba(0,0,0,0.4)",
          }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-4">
            {/* Sidebar */}
            <div
              className="hidden lg:block"
              style={{
                background: "rgba(255,255,255,0.02)",
                borderRight: "1px solid rgba(255,255,255,0.08)",
                padding: 24,
              }}
            >
              {["Overview", "Interviews", "Analytics", "Resume", "Settings"].map(
                (item, i) => (
                  <div
                    key={item}
                    className="flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors"
                    style={{
                      background:
                        i === 0 ? "rgba(255,255,255,0.03)" : "transparent",
                      borderLeft: i === 0 ? "2px solid #6d5b45" : "2px solid transparent",
                      marginLeft: -2,
                    }}
                  >
                    <span
                      style={{
                        fontSize: 14,
                        color: i === 0 ? "#fff" : "rgba(255,255,255,0.6)",
                      }}
                    >
                      {item}
                    </span>
                  </div>
                ),
              )}
            </div>

            {/* Main Content */}
            <div className="lg:col-span-2 p-8">
              {/* Stats */}
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: "Overall Score", value: "82", change: "+12%", color: "#4ade80" },
                  { label: "Interviews", value: "24", sub: "This month", color: "#fff" },
                  { label: "Avg. Duration", value: "18m", sub: "Per session", color: "#fff" },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      borderRadius: 10,
                      padding: 20,
                    }}
                  >
                    <span
                      style={{
                        fontFamily: "'Instrument Serif', Georgia, serif",
                        fontSize: "clamp(28px, 3vw, 48px)",
                        fontWeight: 400,
                        color: stat.color,
                      }}
                    >
                      {stat.value}
                    </span>
                    <p
                      className="mt-1"
                      style={{
                        fontFamily: "Geist, sans-serif",
                        fontWeight: 300,
                        fontSize: 12,
                        color: stat.change
                          ? "#4ade80"
                          : "rgba(255,255,255,0.35)",
                      }}
                    >
                      {stat.change || stat.sub}
                    </p>
                  </div>
                ))}
              </div>

              {/* Chart Area */}
              <div className="mt-6">
                <h4
                  style={{
                    fontFamily: "Geist, sans-serif",
                    fontWeight: 500,
                    fontSize: 14,
                    color: "#fff",
                    marginBottom: 16,
                  }}
                >
                  Performance Over Time
                </h4>
                <svg viewBox="0 0 400 120" className="w-full" style={{ height: 120 }}>
                  {/* Grid lines */}
                  {[0, 30, 60, 90].map((y) => (
                    <line
                      key={y}
                      x1="0"
                      y1={y}
                      x2="400"
                      y2={y}
                      stroke="rgba(255,255,255,0.04)"
                      strokeWidth="1"
                      strokeDasharray="4 4"
                    />
                  ))}
                  {/* Area fill */}
                  <defs>
                    <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6d5b45" stopOpacity="0.15" />
                      <stop offset="100%" stopColor="#6d5b45" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M0,80 C50,70 80,50 130,55 C180,60 200,30 260,35 C320,40 350,20 400,15 L400,120 L0,120 Z"
                    fill="url(#chartGrad)"
                  />
                  {/* Line */}
                  <path
                    d="M0,80 C50,70 80,50 130,55 C180,60 200,30 260,35 C320,40 350,20 400,15"
                    fill="none"
                    stroke="url(#lineGrad)"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                  <defs>
                    <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#6d5b45" />
                      <stop offset="100%" stopColor="#8a7a62" />
                    </linearGradient>
                  </defs>
                  {/* X-axis labels */}
                  {["Jan", "Feb", "Mar", "Apr", "May", "Jun"].map((m, i) => (
                    <text
                      key={m}
                      x={(i / 5) * 400}
                      y={115}
                      fill="rgba(255,255,255,0.35)"
                      fontSize="10"
                      fontFamily="'Geist Mono', monospace"
                      textAnchor="middle"
                    >
                      {m}
                    </text>
                  ))}
                </svg>
              </div>
            </div>

            {/* Right Panel */}
            <div
              className="hidden lg:block"
              style={{
                background: "rgba(255,255,255,0.02)",
                borderLeft: "1px solid rgba(255,255,255,0.08)",
                padding: 24,
              }}
            >
              <h4
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 500,
                  fontSize: 14,
                  color: "#fff",
                  marginBottom: 12,
                }}
              >
                Recent Sessions
              </h4>
              <div>
                {recentSessions.map((s, i) => (
                  <div
                    key={i}
                    className="py-3"
                    style={{
                      borderBottom:
                        i < 2
                          ? "1px solid rgba(255,255,255,0.06)"
                          : "none",
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p
                          style={{
                            fontSize: 14,
                            color: "#fff",
                          }}
                        >
                          {s.role}
                        </p>
                        <p
                          style={{
                            fontSize: 12,
                            color: "rgba(255,255,255,0.35)",
                          }}
                        >
                          {s.date}
                        </p>
                      </div>
                      <span
                        className={`score-badge ${s.score >= 8 ? "success" : s.score >= 5 ? "warning" : "error"}`}
                      >
                        {s.score}/10
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <h4
                className="mt-6"
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 500,
                  fontSize: 14,
                  color: "#fff",
                  marginBottom: 12,
                }}
              >
                Skill Breakdown
              </h4>
              <div className="space-y-3">
                {skillBreakdown.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between mb-1">
                      <span
                        style={{
                          fontSize: 12,
                          color: "rgba(255,255,255,0.6)",
                        }}
                      >
                        {skill.name}
                      </span>
                      <span
                        style={{
                          fontFamily: "'Geist Mono', monospace",
                          fontSize: 11,
                          color: "rgba(255,255,255,0.35)",
                        }}
                      >
                        {skill.score}%
                      </span>
                    </div>
                    <div
                      style={{
                        height: 6,
                        borderRadius: 3,
                        background: "rgba(255,255,255,0.06)",
                        overflow: "hidden",
                      }}
                    >
                      <div
                        style={{
                          height: "100%",
                          borderRadius: 3,
                          background: skill.color,
                          width: skillBarsAnimated ? `${skill.score}%` : "0%",
                          transition: "width 0.8s ease-out",
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── Testimonials Section ────────────────────────────────────── */

function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sectionRef.current) return;
    const cards = sectionRef.current.querySelectorAll(".testimonial-card");
    gsap.fromTo(
      cards,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: "power3.out",
        scrollTrigger: { trigger: sectionRef.current, start: "top 80%" },
      },
    );
    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  const testimonials = [
    {
      quote:
        "After 12 practice sessions targeting my weak areas in system design, I walked into my Google interview with complete confidence. The AI feedback was incredibly specific — things I never would have caught on my own.",
      name: "Sarah Chen",
      role: "Senior Engineer",
      company: "Google",
      result: "Received offer",
      avatar: "/avatar-1.jpg",
    },
    {
      quote:
        "The resume ATS analysis alone was worth it. I discovered my resume wasn't even getting past the automated filters. Three weeks of targeted practice later, I had three interviews lined up.",
      name: "Marcus Johnson",
      role: "Product Manager",
      company: "Stripe",
      result: "Received offer",
      avatar: "/avatar-2.jpg",
    },
    {
      quote:
        "I was struggling with behavioral questions specifically. PrepGenius generated hundreds of variations and helped me structure my answers using the STAR method naturally. Landed my dream role at Netflix.",
      name: "Priya Sharma",
      role: "Data Scientist",
      company: "Netflix",
      result: "Received offer",
      avatar: "/avatar-3.jpg",
    },
  ];

  return (
    <section
      id="testimonials"
      ref={sectionRef}
      style={{ background: "#151515", padding: "120px 48px" }}
    >
      <div className="mx-auto" style={{ maxWidth: 1200 }}>
        <span
          style={{
            fontFamily: "'Geist Mono', monospace",
            fontSize: 11,
            letterSpacing: "0.08em",
            color: "rgba(255,255,255,0.35)",
            textTransform: "uppercase",
          }}
        >
          CANDIDATE STORIES
        </span>
        <h2
          style={{
            fontFamily: "'Instrument Serif', Georgia, serif",
            fontSize: "clamp(32px, 4vw, 56px)",
            fontWeight: 400,
            color: "#fff",
            maxWidth: 500,
            marginTop: 16,
            lineHeight: 1.05,
            letterSpacing: "-0.02em",
          }}
        >
          Real results from real practice.
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="testimonial-card"
              style={{
                background: "#0a0a0a",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 14,
                padding: 32,
              }}
            >
              <Quote
                size={32}
                strokeWidth={1}
                style={{ color: "rgba(255,255,255,0.1)" }}
              />
              <p
                className="mt-2"
                style={{
                  fontFamily: "'Instrument Serif', Georgia, serif",
                  fontSize: 20,
                  fontStyle: "italic",
                  color: "#fff",
                  lineHeight: 1.5,
                }}
              >
                {t.quote}
              </p>
              <div
                style={{
                  height: 1,
                  background: "rgba(255,255,255,0.08)",
                  margin: "24px 0",
                }}
              />
              <div className="flex items-center gap-3.5">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-11 h-11 rounded-full object-cover"
                  style={{ filter: "grayscale(0.3)" }}
                />
                <div>
                  <p
                    style={{
                      fontFamily: "Geist, sans-serif",
                      fontWeight: 500,
                      fontSize: 15,
                      color: "#fff",
                    }}
                  >
                    {t.name}
                  </p>
                  <p
                    style={{
                      fontFamily: "Geist, sans-serif",
                      fontWeight: 300,
                      fontSize: 13,
                      color: "rgba(255,255,255,0.35)",
                    }}
                  >
                    {t.role} · {t.company}
                  </p>
                </div>
              </div>
              <div
                className="mt-4 inline-flex items-center px-3 py-1.5 rounded"
                style={{
                  border: "1px solid rgba(74, 222, 128, 0.3)",
                  background: "rgba(74, 222, 128, 0.08)",
                }}
              >
                <span
                  style={{
                    fontFamily: "Geist, sans-serif",
                    fontWeight: 500,
                    fontSize: 12,
                    color: "#4ade80",
                  }}
                >
                  {t.result}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Pricing Section ──────────────────────────────────────────── */

function PricingSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [annual, setAnnual] = useState(true);

  useEffect(() => {
    if (!sectionRef.current) return;
    const cards = sectionRef.current.querySelectorAll(".pricing-card");
    gsap.fromTo(
      cards,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.7,
        stagger: 0.12,
        ease: "power3.out",
        scrollTrigger: { trigger: sectionRef.current, start: "top 80%" },
      },
    );
    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  const plans = [
    {
      name: "Starter",
      price: "Free",
      detail: "Forever free",
      features: [
        "3 mock interviews/month",
        "Basic resume analysis",
        "Limited question bank",
        "Community support",
      ],
      cta: "Get Started",
      highlighted: false,
    },
    {
      name: "Pro",
      price: annual ? "$15" : "$19",
      detail: annual ? "Billed annually" : "Billed monthly",
      features: [
        "Unlimited mock interviews",
        "Advanced ATS analysis",
        "Full question bank",
        "Priority AI feedback",
        "Progress analytics",
        "Interview history",
      ],
      cta: "Start Free Trial",
      highlighted: true,
    },
    {
      name: "Team",
      price: annual ? "$39" : "$49",
      detail: "Per user, billed annually",
      features: [
        "Everything in Pro",
        "Team analytics",
        "Admin dashboard",
        "Custom question sets",
        "SSO & SAML",
        "Dedicated support",
      ],
      cta: "Contact Sales",
      highlighted: false,
    },
  ];

  return (
    <section
      id="pricing"
      ref={sectionRef}
      style={{ background: "#0a0a0a", padding: "120px 48px" }}
    >
      <div className="mx-auto" style={{ maxWidth: 1200 }}>
        <span
          style={{
            fontFamily: "'Geist Mono', monospace",
            fontSize: 11,
            letterSpacing: "0.08em",
            color: "rgba(255,255,255,0.35)",
            textTransform: "uppercase",
          }}
        >
          PRICING
        </span>
        <h2
          style={{
            fontFamily: "'Instrument Serif', Georgia, serif",
            fontSize: "clamp(32px, 4vw, 56px)",
            fontWeight: 400,
            color: "#fff",
            maxWidth: 500,
            marginTop: 16,
            lineHeight: 1.05,
            letterSpacing: "-0.02em",
          }}
        >
          Simple, transparent pricing.
        </h2>
        <p
          style={{
            fontFamily: "Geist, sans-serif",
            fontWeight: 300,
            fontSize: 18,
            color: "rgba(255,255,255,0.6)",
            maxWidth: 440,
            marginTop: 16,
            lineHeight: 1.6,
          }}
        >
          Start free, upgrade when you're ready to accelerate your preparation.
        </p>

        {/* Toggle */}
        <div className="flex items-center justify-center gap-4 mt-10">
          <span
            style={{
              fontSize: 14,
              color: !annual ? "#fff" : "rgba(255,255,255,0.6)",
              transition: "color 0.2s",
            }}
          >
            Monthly
          </span>
          <button
            onClick={() => setAnnual(!annual)}
            className="relative"
            style={{
              width: 44,
              height: 24,
              borderRadius: 12,
              background: annual ? "#6d5b45" : "rgba(255,255,255,0.08)",
              border: "none",
              transition: "background 0.2s",
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 3,
                left: annual ? 23 : 3,
                width: 18,
                height: 18,
                borderRadius: "50%",
                background: "#151515",
                boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
                transition: "left 0.2s",
              }}
            />
          </button>
          <span
            style={{
              fontSize: 14,
              color: annual ? "#fff" : "rgba(255,255,255,0.6)",
              transition: "color 0.2s",
            }}
          >
            Annual
          </span>
          <span
            className="px-2 py-0.5 rounded"
            style={{
              fontSize: 11,
              fontWeight: 500,
              color: "#6d5b45",
              background: "rgba(109, 91, 69, 0.15)",
            }}
          >
            Save 20%
          </span>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12" style={{ maxWidth: 1000, margin: "48px auto 0" }}>
          {plans.map((plan) => (
            <div
              key={plan.name}
              className="pricing-card relative"
              style={{
                background: plan.highlighted
                  ? "linear-gradient(180deg, rgba(109, 91, 69, 0.06) 0%, #151515 30%)"
                  : "#151515",
                border: plan.highlighted
                  ? "1px solid rgba(109, 91, 69, 0.4)"
                  : "1px solid rgba(255,255,255,0.08)",
                borderRadius: 14,
                padding: 40,
                boxShadow: plan.highlighted
                  ? "0 8px 32px rgba(109, 91, 69, 0.1)"
                  : "none",
              }}
            >
              {plan.highlighted && (
                <div
                  className="absolute left-1/2 -translate-x-1/2"
                  style={{ top: -14 }}
                >
                  <span
                    className="px-3 py-1 rounded"
                    style={{
                      background: "#6d5b45",
                      color: "#fff",
                      fontSize: 11,
                      fontWeight: 500,
                      textTransform: "uppercase",
                    }}
                  >
                    Most Popular
                  </span>
                </div>
              )}
              <h3
                style={{
                  fontFamily: "Geist, sans-serif",
                  fontWeight: 500,
                  fontSize: 18,
                  color: "#fff",
                }}
              >
                {plan.name}
              </h3>
              <div className="mt-4">
                <span
                  style={{
                    fontFamily: "'Instrument Serif', Georgia, serif",
                    fontSize: 40,
                    fontWeight: 400,
                    color: "#fff",
                  }}
                >
                  {plan.price}
                </span>
                {plan.price !== "Free" && (
                  <span
                    className="ml-1"
                    style={{
                      fontSize: 14,
                      color: "rgba(255,255,255,0.6)",
                    }}
                  >
                    /mo
                  </span>
                )}
              </div>
              <p
                className="mt-1"
                style={{
                  fontSize: 13,
                  color: "rgba(255,255,255,0.35)",
                }}
              >
                {plan.detail}
              </p>

              <div className="mt-8 space-y-3">
                {plan.features.map((f) => (
                  <div key={f} className="flex items-center gap-2.5">
                    <Check size={14} style={{ color: "#4ade80" }} />
                    <span
                      style={{
                        fontSize: 14,
                        fontWeight: 300,
                        color: "rgba(255,255,255,0.6)",
                      }}
                    >
                      {f}
                    </span>
                  </div>
                ))}
              </div>

              <button
                className="w-full mt-8 py-3 rounded-lg font-medium transition-all duration-200"
                style={{
                  background: plan.highlighted ? "#6d5b45" : "transparent",
                  border: plan.highlighted
                    ? "none"
                    : "1px solid rgba(255,255,255,0.08)",
                  color: "#fff",
                }}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── CTA Section ──────────────────────────────────────────────── */

function CTASection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sectionRef.current) return;
    gsap.fromTo(
      sectionRef.current.querySelector(".cta-container"),
      { opacity: 0, scale: 0.96 },
      {
        opacity: 1,
        scale: 1,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: { trigger: sectionRef.current, start: "top 80%" },
      },
    );
    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      style={{ background: "#151515", padding: "100px 48px" }}
    >
      <div
        className="cta-container mx-auto text-center"
        style={{
          maxWidth: 800,
          background:
            "linear-gradient(135deg, rgba(109, 91, 69, 0.08) 0%, transparent 50%)",
          border: "1px solid rgba(109, 91, 69, 0.15)",
          borderRadius: 14,
          padding: "64px 48px",
        }}
      >
        <h2
          style={{
            fontFamily: "'Instrument Serif', Georgia, serif",
            fontSize: "clamp(32px, 4vw, 48px)",
            fontWeight: 400,
            color: "#fff",
          }}
        >
          Ready to land your dream role?
        </h2>
        <p
          className="mx-auto mt-4"
          style={{
            fontFamily: "Geist, sans-serif",
            fontWeight: 300,
            fontSize: 18,
            color: "rgba(255,255,255,0.6)",
            maxWidth: 520,
            lineHeight: 1.6,
          }}
        >
          Join 10,000+ candidates who've transformed their interview performance
          with AI-powered practice.
        </p>
        <Link
          to="/interview"
          className="inline-block mt-8 px-9 py-4 rounded-lg font-medium transition-all duration-200 hover:-translate-y-0.5"
          style={{
            background: "#6d5b45",
            color: "#fff",
            fontSize: 16,
            boxShadow: "0 8px 30px rgba(109, 91, 69, 0.3)",
          }}
        >
          Start Practicing Free
        </Link>
        <p
          className="mt-4"
          style={{
            fontFamily: "Geist, sans-serif",
            fontWeight: 300,
            fontSize: 13,
            color: "rgba(255,255,255,0.35)",
          }}
        >
          No credit card required. Free plan includes 3 interviews.
        </p>
      </div>
    </section>
  );
}

/* ─── Footer ───────────────────────────────────────────────────── */

function Footer() {
  const linkGroups = [
    {
      title: "Product",
      links: [
        "Interview Simulator",
        "Resume Analysis",
        "Analytics Dashboard",
        "Pricing",
        "Changelog",
      ],
    },
    {
      title: "Resources",
      links: ["Documentation", "API Reference", "Blog", "Community", "Support"],
    },
    {
      title: "Company",
      links: ["About", "Careers", "Privacy Policy", "Terms of Service", "Contact"],
    },
    {
      title: "Connect",
      links: ["Twitter", "LinkedIn", "GitHub", "Discord", "Newsletter"],
    },
  ];

  return (
    <footer
      style={{
        background: "#0a0a0a",
        padding: "64px 48px 32px",
        borderTop: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <div
        className="mx-auto grid grid-cols-1 md:grid-cols-6 gap-10"
        style={{ maxWidth: 1200 }}
      >
        {/* Brand */}
        <div className="md:col-span-2">
          <Link to="/" className="flex items-center gap-2">
            <Hexagon className="text-[#6d5b45]" size={28} strokeWidth={1.5} />
            <span className="text-white font-medium" style={{ fontSize: 16 }}>
              PrepGenius
            </span>
          </Link>
          <p
            className="mt-3"
            style={{
              fontFamily: "Geist, sans-serif",
              fontWeight: 300,
              fontSize: 14,
              color: "rgba(255,255,255,0.6)",
              maxWidth: 240,
              lineHeight: 1.5,
            }}
          >
            AI-powered interview preparation for ambitious candidates.
          </p>
        </div>

        {/* Link Groups */}
        {linkGroups.map((group) => (
          <div key={group.title}>
            <h4
              style={{
                fontFamily: "Geist, sans-serif",
                fontWeight: 500,
                fontSize: 13,
                color: "#fff",
                textTransform: "uppercase",
                letterSpacing: "0.03em",
                marginBottom: 16,
              }}
            >
              {group.title}
            </h4>
            <ul className="space-y-0">
              {group.links.map((link) => (
                <li key={link}>
                  <span
                    className="inline-block py-1 transition-colors duration-200 hover:text-white"
                    style={{
                      fontFamily: "Geist, sans-serif",
                      fontWeight: 300,
                      fontSize: 14,
                      color: "rgba(255,255,255,0.6)",
                      lineHeight: 2.2,
                    }}
                  >
                    {link}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Bottom Bar */}
      <div
        className="mx-auto flex flex-col md:flex-row justify-between items-center mt-12 pt-6"
        style={{
          maxWidth: 1200,
          borderTop: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <span
          style={{
            fontFamily: "Geist, sans-serif",
            fontWeight: 300,
            fontSize: 13,
            color: "rgba(255,255,255,0.35)",
          }}
        >
          PrepGenius AI. All rights reserved.
        </span>
        <div className="flex items-center gap-2 mt-2 md:mt-0">
          <span
            className="inline-block w-1.5 h-1.5 rounded-full"
            style={{ background: "#4ade80" }}
          />
          <span
            style={{
              fontFamily: "Geist, sans-serif",
              fontWeight: 300,
              fontSize: 13,
              color: "rgba(255,255,255,0.35)",
            }}
          >
            All systems operational
          </span>
        </div>
      </div>
    </footer>
  );
}
