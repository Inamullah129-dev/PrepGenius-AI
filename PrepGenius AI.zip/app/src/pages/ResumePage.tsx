import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import Navigation from "@/components/Navigation";
import {
  Upload,
  FileText,
  ArrowLeft,
  CheckCircle,
  AlertTriangle,
  Lightbulb,
  BarChart3,
  Sparkles,
  Trash2,
  Plus,
} from "lucide-react";

export default function ResumePage() {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();

  const [fileName, setFileName] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzedResume, setAnalyzedResume] = useState<number | null>(null);

  const { data: resumesList } = trpc.resume.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createResume = trpc.resume.create.useMutation({
    onSuccess: (data) => {
      if (data) {
        setAnalyzedResume(data.id);
      }
    },
  });

  const analyzeResume = trpc.resume.analyze.useMutation({
    onSuccess: () => {
      utils.resume.list.invalidate();
      utils.analytics.dashboard.invalidate();
      setAnalyzing(false);
    },
  });

  const deleteResume = trpc.resume.delete.useMutation({
    onSuccess: () => {
      utils.resume.list.invalidate();
      setAnalyzedResume(null);
    },
  });

  const { data: resumeDetail } = trpc.resume.getById.useQuery(
    { id: analyzedResume! },
    { enabled: !!analyzedResume },
  );

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      createResume.mutate({ fileName: file.name });
    }
  };

  const handleAnalyze = () => {
    if (analyzedResume) {
      setAnalyzing(true);
      analyzeResume.mutate({ id: analyzedResume });
    }
  };

  const latestResume = resumeDetail ?? resumesList?.[0];

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0a0a" }}>
        <div className="text-center">
          <h2 style={{ fontFamily: "'Instrument Serif', Georgia, serif", fontSize: 28, color: "#fff" }}>
            Sign in to analyze your resume
          </h2>
          <button
            onClick={() => navigate("/login")}
            className="mt-4 px-6 py-3 rounded-lg font-medium"
            style={{ background: "#6d5b45", color: "#fff" }}
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const atsScore = latestResume?.atsScore ?? 0;
  const analysis = latestResume?.analysis;
  const parsedData = latestResume?.parsedData;

  return (
    <div className="min-h-screen" style={{ background: "#0a0a0a" }}>
      <Navigation />
      <div style={{ paddingTop: 80 }}>
        <div className="mx-auto px-6 py-8" style={{ maxWidth: 1000 }}>
          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <button
              onClick={() => navigate("/dashboard")}
              className="p-2 rounded-lg transition-colors"
              style={{ background: "rgba(255,255,255,0.05)" }}
            >
              <ArrowLeft size={18} style={{ color: "rgba(255,255,255,0.6)" }} />
            </button>
            <div>
              <h1
                style={{
                  fontFamily: "'Instrument Serif', Georgia, serif",
                  fontSize: 32,
                  fontWeight: 400,
                  color: "#fff",
                }}
              >
                Resume ATS Analyzer
              </h1>
              <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)" }}>
                Upload your resume and get detailed ATS compatibility insights
              </p>
            </div>
          </div>

          {/* Upload Section */}
          {!latestResume?.atsScore && (
            <div
              className="p-8 rounded-xl mb-8 text-center"
              style={{
                background: "#151515",
                border: "2px dashed rgba(255,255,255,0.1)",
              }}
            >
              <Upload size={40} style={{ color: "#6d5b45", margin: "0 auto 16px" }} />
              <h3 style={{ fontSize: 18, fontWeight: 500, color: "#fff", marginBottom: 8 }}>
                Upload Your Resume
              </h3>
              <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", marginBottom: 24 }}>
                Supports PDF and DOCX formats
              </p>
              <label
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all cursor-pointer hover:-translate-y-0.5"
                style={{
                  background: "#6d5b45",
                  color: "#fff",
                  boxShadow: "0 4px 20px rgba(109, 91, 69, 0.25)",
                }}
              >
                <Plus size={18} />
                Select File
                <input
                  type="file"
                  accept=".pdf,.docx"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </label>
              {fileName && (
                <p className="mt-4" style={{ fontSize: 13, color: "rgba(255,255,255,0.4)" }}>
                  Selected: {fileName}
                </p>
              )}
              {analyzedResume && !latestResume?.atsScore && (
                <button
                  onClick={handleAnalyze}
                  disabled={analyzing}
                  className="mt-4 flex items-center gap-2 mx-auto px-6 py-3 rounded-lg font-medium"
                  style={{ background: "rgba(109, 91, 69, 0.2)", color: "#6d5b45" }}
                >
                  {analyzing ? (
                    <div className="animate-spin w-4 h-4 border-2 border-[#6d5b45] border-t-transparent rounded-full" />
                  ) : (
                    <Sparkles size={18} />
                  )}
                  {analyzing ? "Analyzing..." : "Run ATS Analysis"}
                </button>
              )}
            </div>
          )}

          {/* Results */}
          {latestResume?.atsScore && (
            <div className="space-y-6">
              {/* Score Header */}
              <div
                className="p-6 rounded-xl"
                style={{
                  background: "#151515",
                  border: "1px solid rgba(255,255,255,0.08)",
                }}
              >
                <div className="flex flex-col sm:flex-row items-center gap-6">
                  {/* Score Circle */}
                  <div
                    className="relative flex items-center justify-center"
                    style={{ width: 120, height: 120 }}
                  >
                    <svg viewBox="0 0 120 120" className="w-full h-full">
                      <circle
                        cx="60"
                        cy="60"
                        r="52"
                        fill="none"
                        stroke="rgba(255,255,255,0.06)"
                        strokeWidth="8"
                      />
                      <circle
                        cx="60"
                        cy="60"
                        r="52"
                        fill="none"
                        stroke={atsScore >= 80 ? "#4ade80" : atsScore >= 60 ? "#fbbf24" : "#f87171"}
                        strokeWidth="8"
                        strokeLinecap="round"
                        strokeDasharray={`${(atsScore / 100) * 327} 327`}
                        transform="rotate(-90 60 60)"
                        style={{ transition: "stroke-dasharray 1s ease-out" }}
                      />
                    </svg>
                    <div className="absolute text-center">
                      <span
                        style={{
                          fontFamily: "'Instrument Serif', Georgia, serif",
                          fontSize: 32,
                          color: "#fff",
                        }}
                      >
                        {atsScore}
                      </span>
                    </div>
                  </div>

                  <div className="flex-1 text-center sm:text-left">
                    <h3 style={{ fontSize: 20, fontWeight: 500, color: "#fff" }}>
                      {atsScore >= 80
                        ? "Excellent ATS Compatibility"
                        : atsScore >= 60
                          ? "Good — Room for Improvement"
                          : "Needs Optimization"}
                    </h3>
                    <p className="mt-1" style={{ fontSize: 14, color: "rgba(255,255,255,0.6)" }}>
                      Your resume scores {atsScore}/100 on ATS readability
                    </p>
                    {latestResume.fileName && (
                      <div className="flex items-center gap-2 mt-3">
                        <FileText size={14} style={{ color: "rgba(255,255,255,0.4)" }} />
                        <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
                          {latestResume.fileName}
                        </span>
                        <button
                          onClick={() => latestResume.id && deleteResume.mutate({ id: latestResume.id })}
                          className="ml-2 p-1 rounded transition-colors hover:bg-red-500/10"
                        >
                          <Trash2 size={12} style={{ color: "#f87171" }} />
                        </button>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={() => {
                      setAnalyzedResume(null);
                      setFileName("");
                    }}
                    className="px-4 py-2 rounded-lg text-sm"
                    style={{
                      border: "1px solid rgba(255,255,255,0.08)",
                      color: "rgba(255,255,255,0.6)",
                    }}
                  >
                    Analyze New
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Missing Skills */}
                {analysis?.missingSkills && analysis.missingSkills.length > 0 && (
                  <div
                    className="p-6 rounded-xl"
                    style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
                  >
                    <h4
                      className="flex items-center gap-2 mb-4"
                      style={{ fontSize: 15, fontWeight: 500, color: "#fbbf24" }}
                    >
                      <AlertTriangle size={16} /> Missing Skills
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {analysis.missingSkills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1.5 rounded-md text-sm"
                          style={{
                            background: "rgba(251, 191, 36, 0.08)",
                            color: "#fbbf24",
                            border: "1px solid rgba(251, 191, 36, 0.15)",
                          }}
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Found Skills */}
                {parsedData?.skills && parsedData.skills.length > 0 && (
                  <div
                    className="p-6 rounded-xl"
                    style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
                  >
                    <h4
                      className="flex items-center gap-2 mb-4"
                      style={{ fontSize: 15, fontWeight: 500, color: "#4ade80" }}
                    >
                      <CheckCircle size={16} /> Detected Skills
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {parsedData.skills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1.5 rounded-md text-sm"
                          style={{
                            background: "rgba(74, 222, 128, 0.08)",
                            color: "#4ade80",
                            border: "1px solid rgba(74, 222, 128, 0.15)",
                          }}
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Formatting Issues */}
                {analysis?.formattingIssues && analysis.formattingIssues.length > 0 && (
                  <div
                    className="p-6 rounded-xl"
                    style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
                  >
                    <h4
                      className="flex items-center gap-2 mb-4"
                      style={{ fontSize: 15, fontWeight: 500, color: "rgba(255,255,255,0.8)" }}
                    >
                      <FileText size={16} /> Formatting Issues
                    </h4>
                    <ul className="space-y-2">
                      {analysis.formattingIssues.map((issue, i) => (
                        <li
                          key={i}
                          className="flex items-start gap-2"
                          style={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}
                        >
                          <span
                            className="mt-1 w-1.5 h-1.5 rounded-full flex-shrink-0"
                            style={{ background: "#fbbf24" }}
                          />
                          {issue}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Suggestions */}
                {analysis?.suggestions && analysis.suggestions.length > 0 && (
                  <div
                    className="p-6 rounded-xl"
                    style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
                  >
                    <h4
                      className="flex items-center gap-2 mb-4"
                      style={{ fontSize: 15, fontWeight: 500, color: "#60a5fa" }}
                    >
                      <Lightbulb size={16} /> Improvement Suggestions
                    </h4>
                    <ul className="space-y-2">
                      {analysis.suggestions.map((suggestion, i) => (
                        <li
                          key={i}
                          className="flex items-start gap-2"
                          style={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}
                        >
                          <span
                            className="mt-1 w-1.5 h-1.5 rounded-full flex-shrink-0"
                            style={{ background: "#60a5fa" }}
                          />
                          {suggestion}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Keyword Match */}
                {analysis?.keywordMatch && (
                  <div
                    className="p-6 rounded-xl"
                    style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
                  >
                    <h4
                      className="flex items-center gap-2 mb-4"
                      style={{ fontSize: 15, fontWeight: 500, color: "#fff" }}
                    >
                      <BarChart3 size={16} /> Keyword Match
                    </h4>
                    <div className="flex items-center gap-4">
                      <div
                        className="relative flex-1 h-3 rounded-full overflow-hidden"
                        style={{ background: "rgba(255,255,255,0.06)" }}
                      >
                        <div
                          className="h-full rounded-full transition-all duration-1000"
                          style={{
                            width: `${analysis.keywordMatch}%`,
                            background: "linear-gradient(90deg, #6d5b45, #8a7a62)",
                          }}
                        />
                      </div>
                      <span
                        style={{
                          fontFamily: "'Geist Mono', monospace",
                          fontSize: 14,
                          color: "#fff",
                        }}
                      >
                        {analysis.keywordMatch}%
                      </span>
                    </div>
                    {analysis.roleMatch && (
                      <p className="mt-3" style={{ fontSize: 13, color: "rgba(255,255,255,0.5)" }}>
                        Best matched role: <span style={{ color: "#6d5b45" }}>{analysis.roleMatch}</span>
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
