import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import Navigation from "@/components/Navigation";
import {
  Mic,
  MessageSquare,
  Play,
  RotateCcw,
  Trophy,
  TrendingUp,
  Award,
  ArrowLeft,
  ChevronRight,
  Clock,
  CheckCircle,
} from "lucide-react";

type InterviewPhase = "setup" | "active" | "feedback";

export default function InterviewPage() {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();

  const [phase, setPhase] = useState<InterviewPhase>("setup");
  const [selectedRole, setSelectedRole] = useState("Frontend Engineer");
  const [selectedDifficulty, setSelectedDifficulty] = useState<"easy" | "medium" | "hard">("medium");
  const [selectedType, setSelectedType] = useState<"technical" | "behavioral" | "mixed">("mixed");
  const [currentInterview, setCurrentInterview] = useState<number | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answer, setAnswer] = useState("");
  const [, setAnswers] = useState<Record<number, string>>({});

  const createInterview = trpc.interview.create.useMutation({
    onSuccess: (data) => {
      if (data) {
        setCurrentInterview(data.id);
        setPhase("active");
        setCurrentQuestion(0);
        setAnswer("");
        setAnswers({});
      }
    },
  });

  const submitAnswer = trpc.interview.submitAnswer.useMutation();
  const completeInterview = trpc.interview.complete.useMutation({
    onSuccess: () => {
      setPhase("feedback");
      utils.interview.list.invalidate();
      utils.analytics.dashboard.invalidate();
    },
  });

  const { data: interviewData } = trpc.interview.getById.useQuery(
    { id: currentInterview! },
    { enabled: !!currentInterview },
  );

  const questions = interviewData?.questions ?? [];
  const currentQ = questions[currentQuestion];

  const handleStart = () => {
    createInterview.mutate({
      role: selectedRole,
      difficulty: selectedDifficulty,
      type: selectedType,
    });
  };

  const handleSubmitAnswer = () => {
    if (!currentQ || !answer.trim()) return;
    
    submitAnswer.mutate({
      questionId: currentQ.id,
      userAnswer: answer,
      score: Math.floor(Math.random() * 4) + 6,
      feedback: "Good response. Consider providing more specific examples and technical depth.",
    });

    setAnswers((prev) => ({ ...prev, [currentQ.id]: answer }));
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((q) => q + 1);
      setAnswer("");
    } else {
      // Complete interview
      if (currentInterview) {
        completeInterview.mutate({ id: currentInterview });
      }
    }
  };

  const handleComplete = () => {
    if (currentInterview) {
      completeInterview.mutate({ id: currentInterview });
    }
  };

  const handleRestart = () => {
    setPhase("setup");
    setCurrentInterview(null);
    setCurrentQuestion(0);
    setAnswer("");
    setAnswers({});
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0a0a" }}>
        <div className="text-center">
          <h2 style={{ fontFamily: "'Instrument Serif', Georgia, serif", fontSize: 28, color: "#fff" }}>
            Sign in to start practicing
          </h2>
          <button
            onClick={() => navigate("/login")}
            className="mt-4 px-6 py-3 rounded-lg font-medium"
            style={{ background: "#6d5b45", color: "#fff" }}
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#0a0a0a" }}>
      <Navigation />
      <div style={{ paddingTop: 80 }}>
        <div className="mx-auto px-6 py-8" style={{ maxWidth: 900 }}>
          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <button
              onClick={() => navigate("/dashboard")}
              className="p-2 rounded-lg transition-colors"
              style={{ background: "rgba(255,255,255,0.05)" }}
            >
              <ArrowLeft size={18} style={{ color: "rgba(255,255,255,0.6)" }} />
            </button>
            <div>
              <h1
                style={{
                  fontFamily: "'Instrument Serif', Georgia, serif",
                  fontSize: 32,
                  fontWeight: 400,
                  color: "#fff",
                }}
              >
                Interview Simulator
              </h1>
              <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)" }}>
                Practice with AI-generated questions tailored to your role
              </p>
            </div>
          </div>

          {/* Phase: Setup */}
          {phase === "setup" && (
            <div className="space-y-6">
              {/* Role Selection */}
              <div
                className="p-6 rounded-xl"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <label
                  className="block mb-4"
                  style={{
                    fontFamily: "'Geist Mono', monospace",
                    fontSize: 11,
                    letterSpacing: "0.05em",
                    color: "rgba(255,255,255,0.5)",
                    textTransform: "uppercase",
                  }}
                >
                  Target Role
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {["Frontend Engineer", "Backend Engineer", "Full Stack Engineer"].map((role) => (
                    <button
                      key={role}
                      onClick={() => setSelectedRole(role)}
                      className="p-4 rounded-lg text-left transition-all"
                      style={{
                        background:
                          selectedRole === role
                            ? "rgba(109, 91, 69, 0.15)"
                            : "rgba(255,255,255,0.02)",
                        border:
                          selectedRole === role
                            ? "1px solid rgba(109, 91, 69, 0.4)"
                            : "1px solid rgba(255,255,255,0.06)",
                      }}
                    >
                      <span style={{ fontSize: 14, color: "#fff" }}>{role}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Difficulty */}
              <div
                className="p-6 rounded-xl"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <label
                  className="block mb-4"
                  style={{
                    fontFamily: "'Geist Mono', monospace",
                    fontSize: 11,
                    letterSpacing: "0.05em",
                    color: "rgba(255,255,255,0.5)",
                    textTransform: "uppercase",
                  }}
                >
                  Difficulty
                </label>
                <div className="flex gap-3">
                  {(["easy", "medium", "hard"] as const).map((d) => (
                    <button
                      key={d}
                      onClick={() => setSelectedDifficulty(d)}
                      className="flex-1 py-3 rounded-lg text-center capitalize transition-all"
                      style={{
                        background:
                          selectedDifficulty === d
                            ? "rgba(109, 91, 69, 0.15)"
                            : "rgba(255,255,255,0.02)",
                        border:
                          selectedDifficulty === d
                            ? "1px solid rgba(109, 91, 69, 0.4)"
                            : "1px solid rgba(255,255,255,0.06)",
                        color: selectedDifficulty === d ? "#fff" : "rgba(255,255,255,0.5)",
                      }}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              {/* Interview Type */}
              <div
                className="p-6 rounded-xl"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <label
                  className="block mb-4"
                  style={{
                    fontFamily: "'Geist Mono', monospace",
                    fontSize: 11,
                    letterSpacing: "0.05em",
                    color: "rgba(255,255,255,0.5)",
                    textTransform: "uppercase",
                  }}
                >
                  Interview Type
                </label>
                <div className="flex gap-3">
                  {([
                    { value: "technical" as const, label: "Technical", icon: <Mic size={16} /> },
                    { value: "behavioral" as const, label: "Behavioral", icon: <MessageSquare size={16} /> },
                    { value: "mixed" as const, label: "Mixed", icon: <TrendingUp size={16} /> },
                  ]).map((t) => (
                    <button
                      key={t.value}
                      onClick={() => setSelectedType(t.value)}
                      className="flex-1 py-3 rounded-lg text-center flex items-center justify-center gap-2 transition-all"
                      style={{
                        background:
                          selectedType === t.value
                            ? "rgba(109, 91, 69, 0.15)"
                            : "rgba(255,255,255,0.02)",
                        border:
                          selectedType === t.value
                            ? "1px solid rgba(109, 91, 69, 0.4)"
                            : "1px solid rgba(255,255,255,0.06)",
                        color: selectedType === t.value ? "#fff" : "rgba(255,255,255,0.5)",
                      }}
                    >
                      {t.icon}
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Start Button */}
              <button
                onClick={handleStart}
                disabled={createInterview.isPending}
                className="w-full py-4 rounded-xl font-medium flex items-center justify-center gap-2 transition-all duration-200 hover:-translate-y-0.5"
                style={{
                  background: "#6d5b45",
                  color: "#fff",
                  fontSize: 16,
                  boxShadow: "0 8px 30px rgba(109, 91, 69, 0.3)",
                }}
              >
                {createInterview.isPending ? (
                  <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full" />
                ) : (
                  <>
                    <Play size={18} />
                    Start Interview
                  </>
                )}
              </button>
            </div>
          )}

          {/* Phase: Active */}
          {phase === "active" && currentQ && (
            <div>
              {/* Progress */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span style={{ fontSize: 13, color: "rgba(255,255,255,0.5)" }}>
                    Question {currentQuestion + 1} of {questions.length}
                  </span>
                  <span style={{ fontSize: 13, color: "rgba(255,255,255,0.5)" }}>
                    <Clock size={14} className="inline mr-1" />
                    {selectedDifficulty === "easy" ? "5:00" : selectedDifficulty === "medium" ? "4:00" : "3:00"}
                  </span>
                </div>
                <div
                  style={{
                    height: 4,
                    borderRadius: 2,
                    background: "rgba(255,255,255,0.06)",
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      height: "100%",
                      borderRadius: 2,
                      background: "linear-gradient(90deg, #6d5b45, #8a7a62)",
                      width: `${((currentQuestion + 1) / questions.length) * 100}%`,
                      transition: "width 0.5s",
                    }}
                  />
                </div>
              </div>

              {/* Question Card */}
              <div
                className="p-6 rounded-xl mb-6"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <span
                    className="px-2 py-0.5 rounded text-xs"
                    style={{
                      background: "rgba(109, 91, 69, 0.15)",
                      color: "#6d5b45",
                    }}
                  >
                    {currentQ.category}
                  </span>
                  <span
                    className="px-2 py-0.5 rounded text-xs capitalize"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      color: "rgba(255,255,255,0.5)",
                    }}
                  >
                    {currentQ.difficulty}
                  </span>
                </div>
                <p
                  style={{
                    fontFamily: "Geist, sans-serif",
                    fontSize: 18,
                    color: "#fff",
                    lineHeight: 1.6,
                  }}
                >
                  {currentQ.question}
                </p>
              </div>

              {/* Answer Input */}
              <div
                className="rounded-xl overflow-hidden"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <textarea
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder="Type your answer here..."
                  className="w-full p-4 bg-transparent resize-none outline-none"
                  style={{
                    color: "#fff",
                    fontSize: 15,
                    lineHeight: 1.6,
                    minHeight: 150,
                  }}
                />
                <div
                  className="flex items-center justify-between px-4 py-3"
                  style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
                >
                  <span style={{ fontSize: 12, color: "rgba(255,255,255,0.35)" }}>
                    {answer.length} characters
                  </span>
                  <button
                    onClick={handleSubmitAnswer}
                    disabled={!answer.trim()}
                    className="flex items-center gap-2 px-5 py-2 rounded-lg font-medium transition-all disabled:opacity-40"
                    style={{ background: "#6d5b45", color: "#fff", fontSize: 14 }}
                  >
                    {currentQuestion < questions.length - 1 ? (
                      <>
                        Next <ChevronRight size={16} />
                      </>
                    ) : (
                      <>
                        Finish <CheckCircle size={16} />
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Skip button for last question */}
              {currentQuestion === questions.length - 1 && (
                <button
                  onClick={handleComplete}
                  className="mt-3 text-sm w-full text-center transition-colors hover:text-white"
                  style={{ color: "rgba(255,255,255,0.35)" }}
                >
                  Skip remaining and see results
                </button>
              )}
            </div>
          )}

          {/* Phase: Feedback */}
          {phase === "feedback" && interviewData && (
            <div className="space-y-6">
              {/* Results Header */}
              <div
                className="p-8 rounded-xl text-center"
                style={{
                  background: "linear-gradient(135deg, rgba(109, 91, 69, 0.1) 0%, #151515 50%)",
                  border: "1px solid rgba(109, 91, 69, 0.2)",
                }}
              >
                <Trophy size={40} style={{ color: "#6d5b45", margin: "0 auto 16px" }} />
                <h2
                  style={{
                    fontFamily: "'Instrument Serif', Georgia, serif",
                    fontSize: 32,
                    color: "#fff",
                  }}
                >
                  Interview Complete
                </h2>
                <div className="mt-4">
                  <span
                    style={{
                      fontFamily: "'Instrument Serif', Georgia, serif",
                      fontSize: 56,
                      color: interviewData.totalScore && interviewData.totalScore >= 8 ? "#4ade80" : "#fbbf24",
                    }}
                  >
                    {interviewData.totalScore ?? "—"}
                  </span>
                  <span style={{ fontSize: 18, color: "rgba(255,255,255,0.5)" }}>/10</span>
                </div>
                <p className="mt-2" style={{ fontSize: 14, color: "rgba(255,255,255,0.6)" }}>
                  {interviewData.feedback ?? "Great effort! Keep practicing to improve."}
                </p>
              </div>

              {/* Score Breakdown */}
              <div
                className="p-6 rounded-xl"
                style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <h3 className="mb-4" style={{ fontSize: 16, fontWeight: 500, color: "#fff" }}>
                  Score Breakdown
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: "Technical", score: interviewData.technicalScore, icon: <Award size={16} />, color: "#4ade80" },
                    { label: "Communication", score: interviewData.communicationScore, icon: <MessageSquare size={16} />, color: "#60a5fa" },
                    { label: "Problem Solving", score: interviewData.problemSolvingScore, icon: <TrendingUp size={16} />, color: "#a78bfa" },
                    { label: "Confidence", score: interviewData.confidenceScore, icon: <Trophy size={16} />, color: "#fbbf24" },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="p-4 rounded-lg"
                      style={{ background: "rgba(255,255,255,0.02)" }}
                    >
                      <div className="flex items-center gap-2 mb-2" style={{ color: item.color }}>
                        {item.icon}
                        <span style={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}>
                          {item.label}
                        </span>
                      </div>
                      <span style={{ fontSize: 24, fontWeight: 500, color: "#fff" }}>
                        {item.score ?? "—"}
                      </span>
                      <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>/10</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Strengths & Improvements */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div
                  className="p-6 rounded-xl"
                  style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
                >
                  <h3 className="mb-3 flex items-center gap-2" style={{ fontSize: 16, fontWeight: 500, color: "#4ade80" }}>
                    <CheckCircle size={18} /> Strengths
                  </h3>
                  <ul className="space-y-2">
                    {(interviewData.strengths ?? ["Technical communication", "Problem approach"]).map((s) => (
                      <li key={s} style={{ fontSize: 14, color: "rgba(255,255,255,0.7)" }}>
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>
                <div
                  className="p-6 rounded-xl"
                  style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
                >
                  <h3 className="mb-3 flex items-center gap-2" style={{ fontSize: 16, fontWeight: 500, color: "#fbbf24" }}>
                    <TrendingUp size={18} /> Areas to Improve
                  </h3>
                  <ul className="space-y-2">
                    {(interviewData.improvements ?? ["Provide more examples", "Deepen technical answers"]).map((i) => (
                      <li key={i} style={{ fontSize: 14, color: "rgba(255,255,255,0.7)" }}>
                        {i}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <button
                  onClick={handleRestart}
                  className="flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2"
                  style={{ background: "#6d5b45", color: "#fff" }}
                >
                  <RotateCcw size={16} />
                  Practice Again
                </button>
                <button
                  onClick={() => navigate("/dashboard")}
                  className="flex-1 py-3 rounded-xl font-medium"
                  style={{
                    border: "1px solid rgba(255,255,255,0.08)",
                    color: "rgba(255,255,255,0.6)",
                    background: "transparent",
                  }}
                >
                  Go to Dashboard
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
