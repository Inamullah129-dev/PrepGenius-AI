import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import Navigation from "@/components/Navigation";
import {
  ArrowLeft,
  User,
  Mail,
  MapPin,
  Link as LinkIcon,
  Github,
  Code,
  Folder,
  Save,
  Loader2,
} from "lucide-react";

export default function ProfilePage() {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();

  const { data: profile } = trpc.profile.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const updateProfile = trpc.profile.update.useMutation({
    onSuccess: () => {
      utils.profile.get.invalidate();
    },
  });

  const [form, setForm] = useState({
    title: profile?.title ?? "",
    bio: profile?.bio ?? "",
    location: profile?.location ?? "",
    linkedin: profile?.linkedin ?? "",
    github: profile?.github ?? "",
    portfolio: profile?.portfolio ?? "",
    skills: (profile?.skills ?? []).join(", "),
  });

  // Update form when profile loads
  useState(() => {
    if (profile) {
      setForm({
        title: profile.title ?? "",
        bio: profile.bio ?? "",
        location: profile.location ?? "",
        linkedin: profile.linkedin ?? "",
        github: profile.github ?? "",
        portfolio: profile.portfolio ?? "",
        skills: (profile.skills ?? []).join(", "),
      });
    }
  });

  const handleSave = () => {
    updateProfile.mutate({
      title: form.title || undefined,
      bio: form.bio || undefined,
      location: form.location || undefined,
      linkedin: form.linkedin || undefined,
      github: form.github || undefined,
      portfolio: form.portfolio || undefined,
      skills: form.skills
        ? form.skills.split(",").map((s) => s.trim()).filter(Boolean)
        : undefined,
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#0a0a0a" }}>
        <div className="text-center">
          <h2 style={{ fontFamily: "'Instrument Serif', Georgia, serif", fontSize: 28, color: "#fff" }}>
            Sign in to view your profile
          </h2>
          <button
            onClick={() => navigate("/login")}
            className="mt-4 px-6 py-3 rounded-lg font-medium"
            style={{ background: "#6d5b45", color: "#fff" }}
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const completionScore = profile?.completionScore ?? 0;

  return (
    <div className="min-h-screen" style={{ background: "#0a0a0a" }}>
      <Navigation />
      <div style={{ paddingTop: 80 }}>
        <div className="mx-auto px-6 py-8" style={{ maxWidth: 800 }}>
          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <button
              onClick={() => navigate("/dashboard")}
              className="p-2 rounded-lg transition-colors"
              style={{ background: "rgba(255,255,255,0.05)" }}
            >
              <ArrowLeft size={18} style={{ color: "rgba(255,255,255,0.6)" }} />
            </button>
            <div>
              <h1
                style={{
                  fontFamily: "'Instrument Serif', Georgia, serif",
                  fontSize: 32,
                  fontWeight: 400,
                  color: "#fff",
                }}
              >
                Profile
              </h1>
              <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)" }}>
                Manage your profile and preferences
              </p>
            </div>
          </div>

          {/* Profile Card */}
          <div
            className="p-6 rounded-xl mb-6"
            style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <div className="flex items-center gap-4">
              {user?.avatar ? (
                <img
                  src={user.avatar}
                  alt={user.name || "User"}
                  className="w-16 h-16 rounded-full object-cover"
                />
              ) : (
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center"
                  style={{ background: "rgba(109, 91, 69, 0.15)" }}
                >
                  <User size={28} style={{ color: "#8a7a62" }} />
                </div>
              )}
              <div>
                <h2 style={{ fontSize: 20, fontWeight: 500, color: "#fff" }}>
                  {user?.name || "User"}
                </h2>
                <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)" }}>
                  {user?.email}
                </p>
              </div>
              <div className="ml-auto">
                <div
                  className="relative flex items-center justify-center"
                  style={{ width: 60, height: 60 }}
                >
                  <svg viewBox="0 0 60 60" className="w-full h-full">
                    <circle cx="30" cy="30" r="25" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="4" />
                    <circle
                      cx="30" cy="30" r="25" fill="none"
                      stroke={completionScore >= 70 ? "#4ade80" : completionScore >= 40 ? "#fbbf24" : "#6d5b45"}
                      strokeWidth="4" strokeLinecap="round"
                      strokeDasharray={`${(completionScore / 100) * 157} 157`}
                      transform="rotate(-90 30 30)"
                      style={{ transition: "stroke-dasharray 1s ease-out" }}
                    />
                  </svg>
                  <span
                    className="absolute text-xs font-medium"
                    style={{ color: "#fff" }}
                  >
                    {completionScore}%
                  </span>
                </div>
              </div>
            </div>
            <p className="mt-2 text-right" style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
              Profile completion
            </p>
          </div>

          {/* Form */}
          <div className="space-y-6">
            {/* Basic Info */}
            <div
              className="p-6 rounded-xl"
              style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              <h3
                className="flex items-center gap-2 mb-4"
                style={{ fontSize: 16, fontWeight: 500, color: "#fff" }}
              >
                <User size={18} style={{ color: "#6d5b45" }} /> Basic Information
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginBottom: 6, display: "block" }}>
                    Professional Title
                  </label>
                  <input
                    type="text"
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    placeholder="e.g. Senior Frontend Engineer"
                    className="w-full px-4 py-2.5 rounded-lg outline-none transition-colors"
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      color: "#fff",
                      fontSize: 14,
                    }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginBottom: 6, display: "block" }}>
                    Location
                  </label>
                  <div className="relative">
                    <MapPin size={14} className="absolute left-3 top-3" style={{ color: "rgba(255,255,255,0.3)" }} />
                    <input
                      type="text"
                      value={form.location}
                      onChange={(e) => setForm({ ...form, location: e.target.value })}
                      placeholder="e.g. San Francisco, CA"
                      className="w-full pl-9 pr-4 py-2.5 rounded-lg outline-none transition-colors"
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.08)",
                        color: "#fff",
                        fontSize: 14,
                      }}
                    />
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <label style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginBottom: 6, display: "block" }}>
                    Bio
                  </label>
                  <textarea
                    value={form.bio}
                    onChange={(e) => setForm({ ...form, bio: e.target.value })}
                    placeholder="Tell us about yourself..."
                    rows={3}
                    className="w-full px-4 py-2.5 rounded-lg outline-none resize-none transition-colors"
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      color: "#fff",
                      fontSize: 14,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Links */}
            <div
              className="p-6 rounded-xl"
              style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              <h3
                className="flex items-center gap-2 mb-4"
                style={{ fontSize: 16, fontWeight: 500, color: "#fff" }}
              >
                <LinkIcon size={18} style={{ color: "#6d5b45" }} /> Links
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginBottom: 6, display: "block" }}>
                    LinkedIn
                  </label>
                  <div className="relative">
                    <Mail size={14} className="absolute left-3 top-3" style={{ color: "rgba(255,255,255,0.3)" }} />
                    <input
                      type="text"
                      value={form.linkedin}
                      onChange={(e) => setForm({ ...form, linkedin: e.target.value })}
                      placeholder="linkedin.com/in/..."
                      className="w-full pl-9 pr-4 py-2.5 rounded-lg outline-none transition-colors"
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.08)",
                        color: "#fff",
                        fontSize: 14,
                      }}
                    />
                  </div>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginBottom: 6, display: "block" }}>
                    GitHub
                  </label>
                  <div className="relative">
                    <Github size={14} className="absolute left-3 top-3" style={{ color: "rgba(255,255,255,0.3)" }} />
                    <input
                      type="text"
                      value={form.github}
                      onChange={(e) => setForm({ ...form, github: e.target.value })}
                      placeholder="github.com/..."
                      className="w-full pl-9 pr-4 py-2.5 rounded-lg outline-none transition-colors"
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.08)",
                        color: "#fff",
                        fontSize: 14,
                      }}
                    />
                  </div>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginBottom: 6, display: "block" }}>
                    Portfolio
                  </label>
                  <div className="relative">
                    <Folder size={14} className="absolute left-3 top-3" style={{ color: "rgba(255,255,255,0.3)" }} />
                    <input
                      type="text"
                      value={form.portfolio}
                      onChange={(e) => setForm({ ...form, portfolio: e.target.value })}
                      placeholder="yoursite.com"
                      className="w-full pl-9 pr-4 py-2.5 rounded-lg outline-none transition-colors"
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        border: "1px solid rgba(255,255,255,0.08)",
                        color: "#fff",
                        fontSize: 14,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Skills */}
            <div
              className="p-6 rounded-xl"
              style={{ background: "#151515", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              <h3
                className="flex items-center gap-2 mb-4"
                style={{ fontSize: 16, fontWeight: 500, color: "#fff" }}
              >
                <Code size={18} style={{ color: "#6d5b45" }} /> Skills
              </h3>
              <div>
                <label style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginBottom: 6, display: "block" }}>
                  Skills (comma-separated)
                </label>
                <input
                  type="text"
                  value={form.skills}
                  onChange={(e) => setForm({ ...form, skills: e.target.value })}
                  placeholder="React, TypeScript, Node.js, Python..."
                  className="w-full px-4 py-2.5 rounded-lg outline-none transition-colors"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    color: "#fff",
                    fontSize: 14,
                  }}
                />
              </div>
              {profile?.skills && profile.skills.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-4">
                  {profile.skills.map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1 rounded-md text-sm"
                      style={{
                        background: "rgba(109, 91, 69, 0.1)",
                        color: "#8a7a62",
                      }}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Save Button */}
            <div className="flex justify-end">
              <button
                onClick={handleSave}
                disabled={updateProfile.isPending}
                className="flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all"
                style={{ background: "#6d5b45", color: "#fff" }}
              >
                {updateProfile.isPending ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Save size={16} />
                )}
                {updateProfile.isPending ? "Saving..." : "Save Profile"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
